Some PDFlib Cookbook examples require special input resources like special
fonts to produce "interesting" results. Sometimes these resources cannot
be distributed together with the PDFlib Cookbook because of license
restrictions, but the user can make them available himself.

The directory "extra_input" is intended for these additional resources that
cannot be delivered together with the PDFlib Cookbook. Specific Cookbok
example programs will contain instructions what to put into the "extra_input"
directory.
