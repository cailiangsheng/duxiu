/* $Id: image_as_text_fill_color.java,v 1.5 2012/04/03 14:35:20 rp Exp $
 * Image as text fill color:
 * Create outline text and fill the interior of the glyphs with an image.
 * 
 * Define a pattern containing an image and use it as the fill color for the
 * text being filled and stroked.

 * Required software: PDFlib/PDFlib+PDI/PPS 8
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.text_output;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class image_as_text_fill_color
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "image_as_text_fill_color.pdf";
    String title = "Image as Text Fill Color";

    pdflib p = null;
    
    String imagefile = "text_filling.tif";
    int font, pattern, image;
    double imageheight, imagewidth, resx, resy;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
        throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.5 $");

        /* Load the font; for PDFlib Lite: change "unicode" to "winansi" */
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the background image */
        image = p.load_image("auto", imagefile, "");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Retrieve the image dimensions (related to its original 
         * resolution)
         */
        imagewidth = p.info_image(image, "imagewidth", "");
        imageheight = p.info_image(image, "imageheight", "");
        
        /* The image may have a resolution above 72 dpi. If we used the
         * returned dimensions (in points) for the pattern height and width
         * and placed our image into the pattern, it wouldn't match the
         * pattern size, and a white margin would be left. To make the pattern
         * the same size as the image we calculate the image size 
         * based on its resolution.
         * 
         * Retrieve the original image resolution
         */
        resx = p.info_image(image, "resx", "");
        resy = p.info_image(image, "resy", "");
        
        /* Calculate the image dimensions for 72 dpi */
        if (resx > 0) {
        	imagewidth = imagewidth * 72 / resx;
        	imageheight = imageheight * 72 / resy;
        }

        /* Create a pattern using the retrieved image dimensions.
         * The painttype parameter must be set to 1 since a colorized
         * image is used (as opposed to an image mask).
         */
        pattern = p.begin_pattern(imagewidth, imageheight, imagewidth,
            imageheight, 1);
        p.fit_image(image, 0, 0, "");
        p.end_pattern();
        p.close_image(image);

        /* Start page */
        p.begin_page_ext(595, 842, "");

        /* Set the pattern as the current fill color. Encapsulate the
         * setcolor() call with save() and restore() to be able to proceed with
         * the original colors.
         */
        p.save();
        /* In addition to filling the text (which is the default), stroke the 
         * text by setting the textrendering mode to 2 (fill and stroke) and
         * defining a stroke color different from black.
         */
        p.set_value("textrendering", 2);
        p.setcolor("stroke", "rgb", 0.5, 0.2, 0.1, 0);
        p.setcolor("fill", "pattern", pattern, 0, 0, 0);
              
        /* Output the text with the current fill color, i.e. the image in terms
         * of the pattern color
         */
        p.setfont(font, 50);
        p.show_xy("Hello World!", 50, 500);
        p.continue_text("(says PDFlib GmbH)");
        
        p.restore();

        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
