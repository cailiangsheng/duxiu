/* $Id: scale_down_imported_pages.java,v 1.1 2008/04/07 14:46:24 katja Exp $
 * Scale down imported pages:
 * Place A4 pages from an imported PDF as A5 pages in the output document
 * 
 * Import the pages of an A4 document and output them unchanged. Then, place
 * them in the output document while scaling them down to A5. 
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document
 */
package com.pdflib.cookbook.pdflib.pdf_import;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class scale_down_imported_pages
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "scale_down_imported_pages.pdf";
    String title = "Scale down Imported Pages";

    pdflib p = null;
    String pdffile = "pCOS-datasheet.pdf";
    int indoc, pageno, endpage, page;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.1 $");

        /* Open the input PDF having A4 page size */
        indoc = p.open_pdi_document(pdffile, "");
        if (indoc == -1)
            throw new Exception("Error: " + p.get_errmsg());

        endpage = (int) p.pcos_get_number(indoc, "length:pages");

        /* Loop over all pages of the input document:
         * Place the imported page without any scaling
         */
        for (pageno = 1; pageno <= endpage; pageno++)
        {
            page = p.open_pdi_page(indoc, pageno, "");

            if (page == -1)
                throw new Exception("Error: " + p.get_errmsg());
            
            /* Start an A4 output page (210mm x 297mm) */
            p.begin_page_ext(595, 842, "");
            
            /* Place the imported page without any scaling */
            p.fit_pdi_page(page, 0, 0, "");
            
            p.end_page_ext("");
            
            p.close_pdi_page(page);
        }
        
        /* Loop over all pages of the input document:
         * Place the imported page while scaling it down to A5
         */
        for (pageno = 1; pageno <= endpage; pageno++)
        {
            page = p.open_pdi_page(indoc, pageno, "");

            if (page == -1)
                throw new Exception("Error: " + p.get_errmsg());
            
            /* Start an A5 output page (148mm x 210mm) */
            p.begin_page_ext(421, 595, "");

            /* Place the imported page while scaling it down to A5 */
            p.fit_pdi_page(page, 0, 0, "boxsize={421 595} fitmethod=meet");
            
            p.end_page_ext("");
            
            p.close_pdi_page(page);
        }
  
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
