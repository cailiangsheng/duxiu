/* $Id: nested_bookmarks.java,v 1.5 2007/10/30 16:16:32 katja Exp $
 * Nested bookmarks:
 * Create bookmarks which are nested in several levels
 * 
 * Create a title page with a top-level bookmark and provide the following
 * pages with bookmarks nested on the second level. Below each of those the
 * second level bookmarks create another bookmark which jumps to a Web site.  
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.interactive;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class nested_bookmarks
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "nested_bookmarks.pdf";
    String title = "Nested Bookmarks";

    pdflib p = null;
    int font, i, numpages = 5, pagewidth=200, pageheight=100; 
    int bm_planes, bm_plane;
    int x = 20, y = 50;
    
    String planes[] =
    {
        "Giant Wing",
        "Long Distance Glider",
        "Cone Head Rocket",
        "Super Dart",
        "German Bi-Plane"
    };

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
        throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.5 $");
        
        /* Load a font */
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Create the title page with a top-level bookmark */
        p.begin_page_ext(pagewidth, pageheight, "");
        p.fit_textline("Kraxi Paper Planes", x, y, "font= " + font +
            " fontsize=14");
        bm_planes = p.create_bookmark("Kraxi Paper Planes", "");
        p.end_page_ext("");

        /* Create further pages with a bookmark each which is nested below the
         * top-level bookmark created above */
        for (i=0; i < numpages; i++)
        {
            int action;
        
            /* Start page */
            p.begin_page_ext(pagewidth, pageheight, "");
        
            /* Output some text on the page */
            p.fit_textline(planes[i], x, y, "font= " + font + " fontsize=14");

            /* Create a "Plane" bookmark on the page which is nested under the 
             * "Kraxi Paper Planes" bookmark */
            bm_plane = p.create_bookmark(planes[i], "parent=" + bm_planes);
        
            /* Create a "URI" action for opening a URL */
            action = p.create_action("URI", "url={http://www.kraxi.com}");
        
            /* Create a bookmark which jumps to be URL defined above. This
             * bookmark is nested on level three under the "Plane" bookmark
             * created above. 
             */
            p.create_bookmark("Jump to the Kraxi Website", 
                 "parent=" + bm_plane + " action={activate=" + action + "}");
   
            p.end_page_ext("");
        }
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
