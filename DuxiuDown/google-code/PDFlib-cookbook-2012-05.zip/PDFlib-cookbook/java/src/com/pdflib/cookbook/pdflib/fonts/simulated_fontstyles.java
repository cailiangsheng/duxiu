/* $Id: simulated_fontstyles.java,v 1.5 2007/10/30 16:16:35 katja Exp $
 * Simulated font styles:
 * Create simulated italic or bold text output
 * 
 * Output text lines and Textflows with simulated obliqued or bold font, which
 * is useful if a real italic or bold variant of the font is not available.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.fonts;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class simulated_fontstyles
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "simulated_fontstyles.pdf";
    String title = "Simulated Font Styles";

    pdflib p = null;
    int font, tf = -1;
    String result, optlist;
 
    String textline = "Our Paper Planes";

    String textflow =
    	"Our paper planes are the ideal way of passing the time. We offer " +
    	"revolutionary new developments of the traditional common paper " +
    	"planes. If your lesson, conference, or lecture turn out to be " +
    	"deadly boring, you can have a wonderful time with our planes.";

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        /* Set an output path according to the name of the topic */
        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.5 $");

        /* Start Page */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");

        /* Load the font */
        font = p.load_font("GenR102", "unicode", "");

        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        

        /* Place a text line with a simulated italic angle of -12. The
         * characters will be slanted by 12 degrees to the right.
         */
        optlist = "font=" + font + " fontsize=20 " + "italicangle=-12";
        p.fit_textline(textline + " (italicangle=-12)", 100, 750, optlist);
        
        
        /* Place a text line with a simulated bold font style */
        optlist = "font=" + font + " fontsize=20 " + "fakebold=true";
        p.fit_textline(textline + " (fakebold=true)", 100, 650, optlist);

           
        /* Place a Textflow with a simulated italic angle of -12. The
         * characters will be slanted by 12 degrees to the right.  
         */
        optlist = "font=" + font +  " fontsize=20  italicangle=-12";

        tf = p.add_textflow(-1, "(italicangle=-12)\n" + textflow, optlist);
        if (tf == -1)
            throw new Exception("Error: " + p.get_errmsg());

        result = p.fit_textflow(tf, 100, 350, 450, 550, "");
        if (!result.equals("_stop"))
        {
            /* Check for errors or more text to be placed */
        }
        p.delete_textflow(tf);
        
        
        /* Place a Textflow with a simulated bold font style */  
        optlist = "font=" + font +  " fontsize=20  fakebold=true";
        
        tf = p.add_textflow(-1, "(fakebold=true)\n" + textflow, optlist);
        if (tf == -1)
            throw new Exception("Error: " + p.get_errmsg());

        result = p.fit_textflow(tf, 100, 100, 450, 300, "");
        if (!result.equals("_stop"))
        {
            /* Check for errors or more text to be placed */
        }
        p.delete_textflow(tf);
        
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
