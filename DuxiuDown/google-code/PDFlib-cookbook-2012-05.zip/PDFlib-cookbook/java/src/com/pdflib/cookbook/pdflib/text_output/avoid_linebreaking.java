/* $Id: avoid_linebreaking.java,v 1.3 2007/11/09 19:02:43 katja Exp $
 * Avoid line breaking:
 * Create a Textflow and define various options for line breaking
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.text_output;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class avoid_linebreaking
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "avoid_linebreaking.pdf";
    String title = "Avoid Line Breaking";

    pdflib p = null;
    int tf = -1, tf_avoid = -1, font;
    String result, optlist, text, text_avoid;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        /* Set an output path according to the name of the topic */
        if (p.begin_document(outfile, "") == -1)
        throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");

        /* Create an A4 Landscape page */
        p.begin_page_ext(0, 0, "width=a4.height height=a4.width");

        /* Load the font */
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        p.setfont(font, 12);
        
        /* ---------------------------------------------------------------------
         * Output text which does not contain any options to avoid line breaking
         * ---------------------------------------------------------------------
         */
        text = "For more information about the Giant Wing Paper Plane see " +
            "our Web site <underline=true>www.kraxi-systems.com" +
            "<underline=false>.<nextline>Alternatively, contact us by email " +
            "via <underline=true>questions@kraxi-systems.com" +
            "<underline=false>. You'll get all information about how to fly " +
            "the Giant Wing in a thunderstorm as soon as possible.";
     
        p.fit_textline("Text without any options to avoid line breaking", 
            50, 430, "");

        /* Create the Textflow from the text */
        optlist = "fontname=Helvetica fontsize=20 encoding=unicode " +
            "leading=140%";
        tf = p.create_textflow(text, optlist);
        if (tf == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        result = p.fit_textflow(tf, 50, 100, 300, 400,
            "fitmethod=auto showborder");
        if (!result.equals("_stop"))
        {
            /* Check for errors */
        }
        p.delete_textflow(tf);
        
        
        /* --------------------------------------------------------------
         * Output the same text but with additional options to avoid line
         * breaking
         * --------------------------------------------------------------
         */
        
        /* Text containing options to avoid any line breaking in the Web 
         * address with "<avoidbreak>...<noavoidbreak>" and to avoid any line
         * breaking after the "-" and "." characters in the email address with
         * "charclass={letter {- .}}>...<charclass=default>".
         */ 
        text_avoid = "For more information about the Giant Wing Paper Plane " +
            "see our Web site <underline=true avoidbreak>" +
            "www.kraxi-systems.com<underline=false noavoidbreak>.<nextline>" +
            "Alternatively, contact us by email via <underline=true " +
            "charclass={letter {- .}}>questions@kraxi-systems.com" +
            "<charclass={default {- .}} underline=false>. You'll get all " +
            "information about how to fly the Giant Wing in a thunderstorm " +
            "as soon as possible.";
        
        p.fit_textline("Text with \"charclass\" and \"avoidbreak\" options",
            450, 430, "");
        
        /* Create the Textflow from the text */
        tf_avoid = p.create_textflow(text_avoid, optlist);
        if (tf_avoid == -1)
            throw new Exception("Error: " + p.get_errmsg());

        result = p.fit_textflow(tf_avoid, 450, 100, 700, 400,
            "fitmethod=auto showborder");
        if (!result.equals("_stop"))
        {
            /* Check for errors */
        }
        p.delete_textflow(tf_avoid);

        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e){
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
