/* $Id: crop_imported_pages.java,v 1.3 2007/10/30 16:16:35 katja Exp $
 * Crop imported pages:
 * Crop pages of an existing PDF document
 *
 * Import a PDF page and reduce the page by some fixed amount before placing
 * it in the output document. The retrieve the dimensions of the imported page
 * and place it on a page size of 1/4 of the original size.
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document
 */
package com.pdflib.cookbook.pdflib.pdf_import;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class crop_imported_pages
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "crop_imported_pages.pdf";
    String title = "Crop Imported Pages";

    pdflib p = null;
    String pdffile = "kraxi_business_cards.pdf";
    int indoc, pageno, endpage, page;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");

        /* Open the input PDF */
        indoc = p.open_pdi_document(pdffile, "");
        if (indoc == -1)
            throw new Exception("Error: " + p.get_errmsg());

        endpage = (int) p.pcos_get_number(indoc, "length:pages");

        /* Loop over all pages of the input document */
        for (pageno = 1; pageno <= endpage; pageno++)
        {
            page = p.open_pdi_page(indoc, pageno, "");

            if (page == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Dummy page size; will be adjusted later */
            p.begin_page_ext(10, 10, "");

            /* Place the imported page without performing
             * any changes on the output page
             */
            p.fit_pdi_page(page, 0, 0, "adjustpage");

            p.end_page_ext("");

            /* Dummy page size; will be adjusted later */
            p.begin_page_ext(10, 10, "");

            /* Place the imported page, adjust the page size
             * to the size of the imported page, and crop the page by 51.
             */
            p.fit_pdi_page(page, -51, -51, "adjustpage");
            
            p.end_page_ext("");
            
            /* Retrieve the dimensions of the imported page and adjust the page
             * size by cropping it to a certain percentage of the imported page
             * size.
             */
            
            /* Retrieve the width and height of the current page (note that
             * indices for the pages pseudo object start at 0):
             */
            double pagewidth = 
                p.pcos_get_number(indoc, "pages[" + (pageno - 1) + "]/width");
            double pageheight = 
                p.pcos_get_number(indoc, "pages[" + (pageno - 1) + "]/height");
            
            /* Set the new page size to 1/4 of the imported page size */
            p.begin_page_ext(pagewidth/4, pageheight/4, "");
            
            /* Place the imported page and scale it to 1/4 of its page size */
            p.fit_pdi_page(page, 0, 0, "boxsize={" + pagewidth/4 + " " +
                pageheight/4 + "} fitmethod=meet");
            
            p.end_page_ext("");
            
            p.close_pdi_page(page);
        }

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
