/* $Id: integrated_clipping_path.java,v 1.4 2007/10/30 16:16:34 katja Exp $
 * Integrated clipping path:
 * Place an image with its integrated clipping path being applied to it
 * 
 * Use an image containing a clipping path. Place it without any clipping 
 * taken place. Then, place the image clipped according to its clipping path.
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: image file
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class integrated_clipping_path
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "integrated_clipping_path.pdf";
    String title = "Integrated Clipping Path";

    pdflib p = null;
    String imagefile = "child_clipped.jpg";
    int font, image, imageclipped;
  
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.4 $");

        /* Load the image with its integrated clipping path being ignored */
        image = p.load_image("auto", imagefile, "honorclippingpath=false");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the same image with its integrated clipping path being
         * considered (which is the default setting)
         */
        imageclipped = p.load_image("auto", imagefile, "");
        if (imageclipped == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load font */
        font = p.load_font("Helvetica", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Start a page with the image dimensions */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        
        /* Place the image without the clipping path being applied to it */
        p.fit_image(image, 100, 450, "boxsize {400 300} fitmethod=meet");
        p.fit_textline("Image without its integrated clipping path being " +
            "applied.", 100, 430, "font=" + font + " fontsize=14");

        /* Place the image with the clipping path being applied to it */
        p.fit_image(imageclipped, 100, 100, "boxsize {400 300} fitmethod=meet");
        p.fit_textline("Image with its integrated clipping path being applied.",
            100, 80, "font=" + font + " fontsize=14");
        
        /* Close the images */
        p.close_image(image);
        p.close_image(imageclipped);
     
        p.end_page_ext("");
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
