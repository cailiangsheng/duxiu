/* $Id: iccprofile_to_image.java,v 1.7 2008/04/08 12:59:33 katja Exp $
 * ICC profile to image:
 * Assign an ICC profile to an image
 * 
 * Apply the "sRGB" ICC profile to an imported RGB image.
 * Apply the "ISOcoated" ICC profile to an imported CMYK image.
 *
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: RGB image file, CMYK image file, ICC profile
 */
package com.pdflib.cookbook.pdflib.color;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class iccprofile_to_image
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "iccprofile_to_image.pdf";
    String title = "ICC profile to image";

    pdflib p = null;
    String imagefile;
    int font, image, icchandle;
    int x = 100, y;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.7 $");
        
        font = p.load_font("Helvetica", "unicode", "");
        if (font == -1)
        	throw new Exception ("Error: " + p.get_errmsg());
        
        /* Start page 1 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        
        
        /* --- Load and output an RGB image without any ICC profile --- *
         * --- assigned to it                                       --- *
         */
        imagefile = "nesrin.jpg";
        y = 450;
        
        /* Load the RGB image. Just for our sample, ignore any ICC profile
         * which might be embedded into the image.
         */
        image = p.load_image("auto", imagefile, "honoriccprofile=false");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
      
        /* Fit the image proportionally into a box */
        p.fit_image(image, x, y, "boxsize={400 300} fitmethod=meet");
        p.fit_textline("RGB image without any ICC profile assigned", x, y-= 30, 
            "font=" + font + " fontsize=14");
        
        p.close_image(image);
        
        
        /* --- Load and output an RGB image with the "sRGB" ICC profile --- *
         * --- assigned to it                                           --- *
         */
        
        /* Load the sRGB profile. sRGB is guaranteed to be always available */
        icchandle = p.load_iccprofile("sRGB", "usage=iccbased");
        if (icchandle == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the RGB image, ignore any ICC profile which might be embedded
         * into the image, and assign the sRGB profile to it
         */
        image = p.load_image("auto", imagefile, "iccprofile=" + icchandle +
            " honoriccprofile=false");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
      
        /* Fit the image proportionally into a box */
        p.fit_image(image, x, y-=350, "boxsize={400 300} fitmethod=meet");
        p.fit_textline("RGB image with the \"sRGB\" ICC profile assigned",
            x, y-= 30, "font=" + font + " fontsize=14");
        
        p.close_image(image);
        
        p.end_page_ext("");
        
        /* Start page 2 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        
 
        /* --- Load and output a CMYK image without any ICC profile --- *
         * --- assigned to it                                       --- *
         */
        imagefile = "nesrin_cmyk.jpg";
        y = 450;
        
        /* Load the CMYK image. Just for our sample, ignore any ICC profile
         * which might be embedded into the image.
         */
        image = p.load_image("auto", imagefile, "honoriccprofile=false");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
      
        /* Fit the image proportionally into a box */
        p.fit_image(image, x, y, "boxsize={400 300} fitmethod=meet");
        p.fit_textline("CMYK image without any ICC profile assigned", x, y-= 30, 
            "font=" + font + " fontsize=14");
        
        p.close_image(image);
        
        /* --- Load and output a CMYK image with the "ISOcoated" --- *
         * --- ICC profile assigned to it                        --- *
         */
        
        /* Load the ISOcoated profile */
    	icchandle = p.load_iccprofile("ISOcoated", "usage=iccbased");
    	if (icchandle == -1)
             throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the CMYK image, ignore any ICC profile which might be embedded
         * into the image, and assign the sRGB profile to it
         */
        image = p.load_image("auto", imagefile, "iccprofile=" + icchandle +
            " honoriccprofile=false");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
      
        /* Fit the image proportionally into a box */
        p.fit_image(image, x, y-=350, "boxsize={400 300} fitmethod=meet");
        p.fit_textline("CMYK image with the \"ISOcoated\" ICC profile assigned",
            x, y-= 30, "font=" + font + " fontsize=14");
        
        p.close_image(image);
        
        p.end_page_ext("");
         
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
