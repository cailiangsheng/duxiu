/* $Id: barcode_font.java,v 1.5 2012/05/07 13:24:47 stm Exp $
 * Barcode font:
 * Output text in a barcode font.
 * 
 * Load a barcode font and output text. Enclose the text in the start and stop 
 * characters which are individually defined by the respective barcode font.
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: font file
 */
package com.pdflib.cookbook.pdflib.fonts;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class barcode_font
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "barcode_font.pdf";
    String title = "Barcode Font";

    pdflib p = null;
    int normalfont, barcodefont;
  
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.5 $");

        /* Start page */
        p.begin_page_ext(150, 120, "");

        /* Load the barcode font.
         * "FRE3OF9X.TTF" is a free 3 of 9 Barcode created by Matthew Welch.
         * See http://www.barcodesinc.com/free-barcode-font/.
         * 
         * For PDFlib Lite: change "unicode" to "winansi"
	 *
         * For a symbol barcode font, please change "unicode" to "builtin".
	 * Please See PDFlib 8.0.4 Tutorial, chapter 5.4.2 and 5.4.3.
         */
        barcodefont = p.load_font("FRE3OF9X", "unicode", "embedding");
        if (barcodefont == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Output text with the barcode font. Note the following when creating
         * barcode text: To create a valid 3 of 9 barcode you have to begin and
         * end it with a special character. Scanners look for this character to
         * know where to start and stop reading the barcode. It is represented
         * in this font with the '*' character. So, to create a barcode for the
         * text "ABC123" you have to type out "*ABC123*". Note that barcode
         * readers will not include the *'s in the text they return. They will
         * just give you the "ABC123".
         */

        p.fit_textline("*ABC123*", 10, 75, "font=" + barcodefont +
            " fontsize=20");
        
        /* For PDFlib Lite: change "unicode" to "winansi" */
        normalfont = p.load_font("Helvetica", "unicode", "");
        if (normalfont == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.fit_textline("*ABC123* ", 10, 60, "font=" + normalfont +
            " fontsize=10");
        p.fit_textline("which will be returned by the", 10, 30, "font=" +
            normalfont + " fontsize=10");
        p.fit_textline("barcode reader as ABC123", 10, 10, "font=" +
            normalfont + " fontsize=10");

        /* Finish page */
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
        ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
