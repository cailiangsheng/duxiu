/* $Id: image_from_url.java,v 1.4 2009/07/13 11:32:31 rjs Exp $
 * Image from URL:
 * Read an image from an URL and place it in a PDF document
 * 
 * Read an image from the URL and store into a PDFlib virtual file (PVF). 
 * Then, load the image data from the PVF and place it on the page.
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.images;
import java.io.*;
import java.net.*;
import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class image_from_url
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "image_from_url.pdf";
    String title = "Image from URL";

    pdflib p = null;
    final String image_url = "http://www.pdflib.com/uploads/media/logo_01.gif";
    byte[] imageData = null;
    URL url = null;

    try {
        byte[] buffer = new byte[1024];
        
        /* Read an image from a Web site */ 
        url = new URL(image_url);
        
        InputStream inp = url.openStream();
        ByteArrayOutputStream bufferStream = new ByteArrayOutputStream();
        
        int bytesRead;
        while ((bytesRead = inp.read(buffer)) != -1) {
            bufferStream.write(buffer, 0, bytesRead);
        }
        
        imageData = bufferStream.toByteArray();
        
        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");
  
            if (p.begin_document(outfile, "") == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.4 $");
		        
            /* Store the image in a PDFlib virtual file (PVF) called
             * "/pvf/image"
             */
            p.create_pvf("/pvf/image", imageData, "");

            /* Load the image from the PVF */
            int image = p.load_image("auto", "/pvf/image" , "");
            if (image == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Start a page, place the image, and finish the page */
            p.begin_page_ext(400, 200, "");
            p.fit_image(image, 50, 100, "");
            p.end_page_ext("");

            /* Delete the virtual file to free the allocated memory */
            p.delete_pvf("/pvf/image");

            p.end_document("");

            } catch (PDFlibException e) {
                System.err.print("PDFlib exception occurred:\n");
                System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                    ": " + e.get_errmsg() + "\n");
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                if (p != null) {
                    p.delete();
                }
            }
	    } catch (IOException e) {
	    	System.err.print("Exception occurred: URL " + image_url +
	    	    " is not available\n");
		    e.printStackTrace();
	    }
    }
}
