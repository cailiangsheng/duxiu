/* $Id: images_to_pdfa.java,v 1.2 2009/07/13 11:32:33 rjs Exp $
 * Images to PDF/A:
 * Convert grayscale, CMYK or RGB image files in TIFF or JPEG formats to 
 * PDF/A-1b, taking care of color space issues.
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: image files
 */
package com.pdflib.cookbook.pdflib.pdfa;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

/**
 * @author stm
 * 
 */
public class images_to_pdfa {
    public static void main(String argv[]) {
        /* This is where the data files are. Adjust as necessary. */
        String searchpath = "../input";
        String outfile = "images_to_pdfa.pdf";
        String title = "Images to PDF/A";

        pdflib p = null;
        String imagefileRGB = "nesrin.jpg";
        String imagefileCMYK = "kraxi_header.tif";
        String imagefileGray = "nesrin_gray.jpg";

        int image, icc;

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            check_pdflib_version(p, 7, 0, 4);

            /* Output all contents conforming to PDF/A-1b */
            if (p.begin_document(outfile, "pdfa=PDF/A-1b:2005") == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.2 $");

            /*
             * Use sRGB as output intent since it allows the color spaces
             * ICC-based, grayscale, and RGB. CMYK images must be tagged with a
             * suitable CMYK ICC profile.
             */
            p.load_iccprofile("sRGB", "usage=outputintent");

            /* Load an ICC profile for CMYK images */
            icc = p.load_iccprofile("ISOcoated.icc", "");
            if (icc == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.begin_page_ext(595, 842, "");

            /*
             * We can use an RGB image without any further options since we
             * supplied an RGB output intent profile.
             */
            image = p.load_image("auto", imagefileRGB, "");
            if (image == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.fit_image(image, 100, 550, "scale=0.5");
            p.close_image(image);

            /*
             * Similarly, we can use a grayscale image without any further
             * options since we supplied an RGB output intent profile.
             */
            image = p.load_image("auto", imagefileGray, "");
            if (image == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.fit_image(image, 100, 250, "scale=0.5");
            p.close_image(image);

            /* For CMYK images we explicitly assign a CMYK ICC profile */
            image = p.load_image("auto", imagefileCMYK, "iccprofile=" + icc);
            if (image == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.fit_image(image, 100, 80, "");
            p.close_image(image);

            p.end_page_ext("");

            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                    + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }

    /**
     * Check whether the required minimum PDFlib version is available
     * 
     * @param p
     *            the pdflib object
     * @param major
     *            PDFlib major version number
     * @param minor
     *            PDFlib minor version number
     * @param revision
     *            PDFlib revision number
     * 
     * @throws PDFlibException
     * @throws Exception
     */
    private static void check_pdflib_version(pdflib p, int major, int minor,
            int revision) throws PDFlibException, Exception {
        final int actualMajor = (int) p.get_value("major", 0);
        final int actualMinor = (int) p.get_value("minor", 0);
        final int actualRevision = (int) p.get_value("revision", 0);

        /* Required minimum PDFlib version */
        final int requiredVersion = major * 100 + minor * 10 + revision;
        final int actualVersion = actualMajor * 100 + actualMinor * 10
                + actualRevision;

        if (actualVersion < requiredVersion) {
            throw new Exception("Error: PDFlib " + major + "." + minor + "."
                    + revision + " or above is required");
        }
    }
}
