/* $Id: pdfa_extension_schema_with_type.java,v 1.2 2009/07/13 11:32:33 rjs Exp $
 * PDF/A extension schema with type:
 * Demonstrate the use of a complex XMP extension schema as defined in PDF/A-1
 * 
 * Create a PDF/A document and use the "metadata" option of begin_document() to
 * supply an XMP file containing a complex XMP extension schema which requires a
 * custom type definition.
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7.0.3
 * Required data: XMP file
 */
package com.pdflib.cookbook.pdflib.pdfa;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class pdfa_extension_schema_with_type {
    public static void main(String argv[]) {
        /* This is where the data files are. Adjust as necessary. */
        String searchpath = "../input";
        String outfile = "pdfa_extension_schema_with_type.pdf";
        String title = "PDF/A Extension Schema with Type";

        pdflib p = null;

        String xmpfile = "machine_extension_schema_2.xmp";
        int font;

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            check_pdflib_version(p, 7, 0, 4);

            /*
             * Start a PDF/A document with an XMP file supplied, containing an
             * XMP extension schema. The XMP metadata will be read from the file
             * and embedded in the document. PDFlib will merge several
             * internally generated entries into the user-supplied XMP, e.g.
             * xmp:CreateDate.
             */
            if (p.begin_document(outfile,
                    "pdfa=PDF/A-1b:2005 metadata={filename={" + xmpfile + "}}")
                                                                        == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.2 $");

            p.begin_page_ext(0, 0, "width=a4.height height=a4.width");

            /* Font embedding is required for PDF/A */
            font = p.load_font("LuciduxSans-Oblique", "unicode", "embedding");

            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.setfont(font, 12);

            p.fit_textline(
                    "An XMP extension schema is read from an XMP file and "
                            + "the XMP metadata is embedded in the document.",
                    50, 400, "");

            p.end_page_ext("");

            p.end_document("");

        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                    + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }

    /**
     * Check whether the required minimum PDFlib version is available
     * 
     * @param p
     *            the pdflib object
     * @param major
     *            PDFlib major version number
     * @param minor
     *            PDFlib minor version number
     * @param revision
     *            PDFlib revision number
     * 
     * @throws PDFlibException
     * @throws Exception
     */
    private static void check_pdflib_version(pdflib p, int major, int minor,
            int revision) throws PDFlibException, Exception {
        final int actualMajor = (int) p.get_value("major", 0);
        final int actualMinor = (int) p.get_value("minor", 0);
        final int actualRevision = (int) p.get_value("revision", 0);

        /* Required minimum PDFlib version */
        final int requiredVersion = major * 100 + minor * 10 + revision;
        final int actualVersion = actualMajor * 100 + actualMinor * 10
                + actualRevision;

        if (actualVersion < requiredVersion) {
            throw new Exception("Error: PDFlib " + major + "." + minor + "."
                    + revision + " or above is required");
        }
    }
}
