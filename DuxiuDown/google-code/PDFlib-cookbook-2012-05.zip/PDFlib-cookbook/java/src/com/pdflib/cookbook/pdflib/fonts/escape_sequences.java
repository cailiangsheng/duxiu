/*
 * $Id: escape_sequences.java,v 1.12 2010/02/08 14:16:03 stm Exp $
 * 
 * Escape sequences:
 * Use escape sequences in text lines to output octal or hexadecimal values 
 * 
 * Output simple text in octal as well as hexadecimal notation using
 * fit_textline().
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.fonts;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class escape_sequences {
    public static void main(String argv[]) {
	final String outfile = "escape_sequences.pdf";
	final String title = "Escape Sequences";

	pdflib p = null;
	final int x = 100, xoff = 200, y = 650, yoff = 35;

	try {
	    p = new pdflib();

	    /* This means we must check return values of load_font() etc. */
	    p.set_parameter("errorpolicy", "return");

	    if (p.begin_document(outfile, "") == -1)
		throw new Exception("Error: " + p.get_errmsg());

	    p.set_info("Creator", "PDFlib Cookbook");
	    p.set_info("Title", title + " $Revision: 1.12 $");

	    /* For PDFlib Lite: change "unicode" to "winansi" */
	    final int font = p.load_font("Helvetica", "unicode", "");
	    if (font == -1)
		throw new Exception("Error: " + p.get_errmsg());

	    /*
	     * While it is possible to specify the the expansion of escape
	     * sequences with a global parameter, this can have unwanted
	     * consequences because for example environment variables are
	     * treated by PDFLib as "name strings", and on Windows the backslash
	     * is used in pathnames (example: environment variable
	     * "PDFLIBLICENSEFILE" for specifying the pathname of the PDFlib
	     * license file).
	     * 
	     * Therefore it is strongly recommended to always specify the
	     * "escapesequence" option for each function where it is necessary,
	     * and not to set it as a parameter like this:
	     * 
	     * p.set_parameter("c", "true");
	     */

	    /* Start page */
	    p.begin_page_ext(0, 0, "width=a4.width height=a4.height");

	    /* Set the font and font size */
	    p.setfont(font, 18);

	    /*
	     * Output some descriptive text, i.e. the header for a kind of
	     * input/output table
	     */
	    p.fit_textline("Input", x, y, "underline underlinewidth=1");
	    p.fit_textline("Output", x + xoff, y, "underline underlinewidth=1");

	    /*
	     * Output some text in octal notation using escape sequences. At the
	     * Java level we need an additional backslash to escape the
	     * backslash itself.
	     */

	    final String testcases[] = {
		// octal notation
		"\\160", // "p"

		// hexadecimal notation
		"\\xC4", // LATIN CAPITAL LETTER A WITH DIARESIS
		"\\xD6", // LATIN CAPITAL LETTER O WITH DIARESIS
		"\\xDC" // LATIN CAPITAL LETTER U WITH DIARESIS
	    };

	    int i;
	    for (i = 0; i < testcases.length; i += 1) {
		final int ypos = y - ((i + 1) * yoff);
		
		/*
		 * Show the input text. As the default for the "escapesequence"
		 * option is "false", the string will be shown as-is.
		 */
		p.fit_textline(testcases[i], x, ypos, "");

		/*
		 * Let PDFlib replace the escape sequence and show the resulting
		 * text.
		 */
		p.fit_textline(testcases[i], x + xoff, ypos,
			"escapesequence=true");
	    }

	    /* Finish page */
	    p.end_page_ext("");

	    p.end_document("");
	}
	catch (PDFlibException e) {
	    System.err.print("PDFlib exception occurred:\n");
	    System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
		    + ": " + e.get_errmsg() + "\n");
	}
	catch (Exception e) {
	    System.err.println(e.getMessage());
	}
	finally {
	    if (p != null) {
		p.delete();
	    }
	}
    }
}
