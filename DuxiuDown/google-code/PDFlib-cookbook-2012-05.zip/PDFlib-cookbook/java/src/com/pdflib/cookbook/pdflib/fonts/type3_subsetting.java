/* $Id: type3_subsetting.java,v 1.5 2009/07/13 11:32:30 rjs Exp $
 * Type 3 subsetting:
 * Demonstrate Type 3 font definition, use, and subsetting
 * 
 * In the first definition pass, create the "T3font" widths-only font by 
 * supplying all font and glyph metrics.
 * Load the "T3font" font with "subsetting" and output some text.
 * In the second definition pass, supply all glyph descriptions for the font.
 * With the "subsetting" option PDFlib will include only those glyphs in the
 * font which are actually used in the document in order to reduce the overall
 * file size. However, the full metrics must be supplied in the first pass of
 * the font definition. 
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.fonts;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class type3_subsetting
{
    private static void define_font(pdflib p, int pass)
    throws PDFlibException, Exception {
        int image;
        
        int data[][] =
        {{0x00, 0x00, 0x00, 0x00, 0x00, 0x78, 0x84, 0x04, 0x7C, 0x84, 0x84, 
          0x8C, 0x76, 0x00, 0x00, 0x00}, /* "a" */
         {0x00, 0x00, 0xC0, 0x40, 0x40, 0x5C, 0x62, 0x42, 0x42, 0x42, 0x42,
          0x62, 0xDC, 0x00, 0x00, 0x00}}; /* "b" */
        
        /* From the data defining three glyphs, create three PVFs
         * "/pvf/font/bitmap0" ... "/pvf/font/bitmap2"
         */
        if (pass == 2) {
            byte [] glyphdef = new byte[data[0].length];
        
            for (int i=0; i < 2; i++) {
                for (int j=0; j < data[0].length; j++)
                    glyphdef[j] = (byte) data[i][j];

                p.create_pvf("/pvf/font/bitmap" + i, glyphdef, "");
            }
        }
        
        /* Create the "T3font" widths-only font in pass 1
         */
        p.begin_font("T3Font", 1/16.0, 0, 0, 1/16.0, 0, -3/16.0,
                pass == 1 ? "widthsonly=true" : "");
                      
        /* The .notdef (fallback) glyph should be contained in all Type 3
         * fonts to avoid problems with some PDF viewers. It is usually empty.
         * Therefore we don't have to distinguish between pass 1 and pass 2.
         */
        p.begin_glyph(".notdef", 8, 0, 0, 0, 0);
        p.end_glyph();
        
        /* Define the glyph "a" */
        p.begin_glyph("a", 8, 0, 0, 8, 16);
        
        /* In pass 2, load the bitmap data for the glyph from the PVF.
         * The "inline" option is provided so that load_image() will
         * internally perform the equivalent of fit_image(image, 0, 0, "")
         * and close_image(image).
         */
        String optlist = 
            "inline bpc=1 components=1 height=16 width=8 mask invert";
        
        if (pass == 2) {
            image = p.load_image("raw", "/pvf/font/bitmap0", optlist);
            if (image == -1 && p.get_errnum() > 0)
                throw new Exception("Error: " + p.get_errmsg());
        }
        
        p.end_glyph();
        
        /* Define the glyph "b" */
        p.begin_glyph("b", 8, 0, 0, 8, 16);
        
        if (pass == 2) {
            image = p.load_image("raw", "/pvf/font/bitmap1", optlist);
            if (image == -1 && p.get_errnum() > 0)
                throw new Exception("Error: " + p.get_errmsg());
        }
       
        p.end_glyph();

        /* ...define all glyph descriptions... */

        p.end_font();
    }
    
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "type3_subsetting.pdf";
    String title = "Type 3 Subsetting";

    pdflib p = null;
    int font;
    
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.5 $");
        
        /* Pass 1: Create the widths-only font to make it known to PDFlib */
        define_font(p, 1);
    
        /* Create some text on the page with glyphs from the font. Loading the
         * font with the "subsetting" option  will include only those glyphs in
         * the font which are actually used in the document.
         */
        p.begin_page_ext(595, 842, "");
        
        font = p.load_font("T3Font", "winansi", "subsetting");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        p.fit_textline("a", 50, 700, "font=" + font + " fontsize=36");
        
        p.end_page_ext("");
        
        /* Pass 2: Supply glyph descriptions for the font */
        define_font(p, 2);
 
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
