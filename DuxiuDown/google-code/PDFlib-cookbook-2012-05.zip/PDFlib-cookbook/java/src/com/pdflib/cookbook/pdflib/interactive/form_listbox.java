/* $Id: form_listbox.java,v 1.3 2007/10/30 16:16:32 katja Exp $
 * Form listbox:
 * Create a form field of type "listbox" for choosing an item from a list.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.interactive;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class form_listbox
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary */
    String searchpath = "../input";
    String outfile = "form_listbox.pdf";
    String title = "Form Listbox";
    
    pdflib p = null;

    String optlist;
    int font;
    double width=150, height=80, llx = 100, lly = 600;
  
    try {
        p = new pdflib();

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        p.set_parameter("SearchPath", searchpath);

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");

        font = p.load_font("Helvetica", "winansi", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Start page */
        p.begin_page_ext(0, 0, " width=a4.width height=a4.height");
        
        /* Output a listbox title */
        p.setfont(font, 14);
        p.fit_textline("Choose a paper plane model:", llx, lly, "");
        lly-=90;
        
        /* Create a form fields of type "listbox".
         * Provide the box with a light gray background
         * (backgroundcolor={gray 0.9}) and a gray border
         * (bordercolor={gray 0.7}).
         * Set the values for the list items (itemnamelist={0 1 2 3}).
         * Set the labels for the list items (itemtextlist={...}).
         * Set the focus on the first item (currentvalue=0).
         */
        optlist = "font=" + font + " fontsize=14 backgroundcolor={gray 0.9} " +
            "bordercolor={gray 0.7} itemnamelist={0 1 2 3} currentvalue=0 " +
            "itemtextlist={{Long Distance Glider} {Giant Wing} {Cone Head " +
            "Rocket} {Super Dart}}";
        
        p.create_field(llx, lly, llx + width, lly + height, "plane", "listbox",
            optlist);
        
        p.end_page_ext("");
        
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
