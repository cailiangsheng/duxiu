/* $Id: process_utf8.java,v 1.5 2007/09/04 12:04:58 katja Exp $
 * Process UTF-8 data:
 * Read text in the UTF-8 format and output it.
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: UTF-8 encoded text file
 */
package com.pdflib.cookbook.pdflib.text_output;

import java.io.*;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class process_utf8
{
    public static void main (String argv[])
    {
    pdflib p = null;
    String searchpath = "../input";
    String infile = "../input/kraxi_paper_planes.utf8";
    String outfile = "process_utf8.pdf";
    String title = "Process UTF-8";

    int font;
    FileInputStream fis;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
        throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.5 $");

        /* For PDFlib Lite: change "unicode" to "winansi" */
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");

        /* Read UTF-8 text data from a file line by line */
        fis = new FileInputStream(infile);
        InputStreamReader isr = new InputStreamReader(fis, "UTF8");
  	    BufferedReader br = new BufferedReader(isr);

        p.setfont(font, 12);
        String line = null;
        boolean first = true;

        while ((line = br.readLine()) != null) {
            if (first) {
         	    p.set_text_pos(50, 700);
                p.show(line);
                first = false;
            } else {
                p.continue_text(line);
            }
        }

        br.close();
        isr.close();
        fis.close();

        /* Convert a UCS-2 string to UTF-8 (this is only to simulate a UTF-8
         * data source. You will usually read the UTF-8 data from a file or
         * database.)
         */
        String text = "Kraxi Paper Planes, Inc.\u00AE";
        byte[] utf8 = text.getBytes("UTF-8");

        /* Convert the string back from UTF-8 to UCS-2 */
        text = new String(utf8, "UTF-8");

        /* In non Unicode capable languages use the "textformat" parameter to
         * notify the PDFlib text output functions to process strings
         * as UTF-8 strings.

        p.set_parameter("textformat", "utf8");

        */

        /* Output the text */
        p.fit_textline(text, 50, 750, "font= " + font + " fontsize=14");

        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
