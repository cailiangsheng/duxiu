/* $Id: import_pdfa.java,v 1.3 2011/08/01 14:44:29 stm Exp $
 * Import PDF/A:
 * Import an existing PDF/A-1b document and output it as PDF/A-1b
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document
 */
package com.pdflib.cookbook.pdflib.pdfa;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class import_pdfa {
    public static void main(String argv[]) {
        /* This is where the data files are. Adjust as necessary. */
        String searchpath = "../input";
        String outfile = "import_pdfa.pdf";
        String title = "Import PDF/A";

        pdflib p = null;
        String pdffile = "PLOP-datasheet-PDFA-1b.pdf";
        int indoc, pageno, endpage, page;
        double ret;
        String res;

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            check_pdflib_version(p, 7, 0, 4);

            if (p.begin_document(outfile, "pdfa=PDF/A-1b:2005") == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.3 $");

            /* Open the input PDF */
            indoc = p.open_pdi_document(pdffile, "");
            if (indoc == -1)
                throw new Exception("Error: " + p.get_errmsg());

            endpage = (int) p.pcos_get_number(indoc, "length:pages");

            /*
             * Since the input document contains its own output intent retrieve
             * the output intent from the input document and copy it to the
             * output document
             */
            res = p.pcos_get_string(indoc, "type:/Root/OutputIntents");
            if (res.equals("array")) {
                ret = p.process_pdi(indoc, -1, "action=copyoutputintent");
                if (ret == -1)
                    throw new Exception("Error: " + p.get_errmsg());
            }

            /* Loop over all pages of the input document */
            for (pageno = 1; pageno <= endpage; pageno++) {
                page = p.open_pdi_page(indoc, pageno, "");

                if (page == -1)
                    throw new Exception("Error: " + p.get_errmsg());

                /* Dummy page size; will be adjusted later */
                p.begin_page_ext(10, 10, "");

                /*
                 * Place the imported page without performing any changes on the
                 * output page
                 */
                p.fit_pdi_page(page, 0, 0, "adjustpage");

                p.close_pdi_page(page);
                p.end_page_ext("");
            }

            p.end_document("");

        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                    + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }

    /**
     * Check whether the required minimum PDFlib version is available
     * 
     * @param p
     *            the pdflib object
     * @param major
     *            PDFlib major version number
     * @param minor
     *            PDFlib minor version number
     * @param revision
     *            PDFlib revision number
     * 
     * @throws PDFlibException
     * @throws Exception
     */
    private static void check_pdflib_version(pdflib p, int major, int minor,
            int revision) throws PDFlibException, Exception {
        final int actualMajor = (int) p.get_value("major", 0);
        final int actualMinor = (int) p.get_value("minor", 0);
        final int actualRevision = (int) p.get_value("revision", 0);

        /* Required minimum PDFlib version */
        final int requiredVersion = major * 100 + minor * 10 + revision;
        final int actualVersion = actualMajor * 100 + actualMinor * 10
                + actualRevision;

        if (actualVersion < requiredVersion) {
            throw new Exception("Error: PDFlib " + major + "." + minor + "."
                    + revision + " or above is required");
        }
    }
}
