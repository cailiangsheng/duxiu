/* $Id: tiling_pattern.java,v 1.3 2012/03/21 14:13:02 rp Exp $
 * Tiling pattern:
 * Define a tiling pattern containing an image and use it to cover the page
 * background with tiles
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 8
 * Required data: image file
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class tiling_pattern
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "tiling_pattern.pdf";
    String title = "Tiling Pattern";

    pdflib p = null;
    String imagefile = "background_image.png";
    int font, image, pattern;
    int pagewidth = 595, pageheight = 842;
    double imagewidth, imageheight, resx, resy;

    try{
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
	p.set_parameter("errorpolicy", "return");

	if (p.begin_document(outfile, "") == -1)
	    throw new Exception("Error: " + p.get_errmsg());

	    p.set_info("Creator", "PDFlib Cookbook");
	    p.set_info("Title", title + " $Revision: 1.3 $");

        /* Load the background image */
        image = p.load_image("auto", imagefile, "");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Retrieve the image dimensions */
        imagewidth = p.info_image(image, "imagewidth", "");
        imageheight = p.info_image(image, "imageheight", "");
        
        /* The image may have a resolution above 72 dpi. If we used the
         * returned dimensions (in points) for the pattern height and width
         * and placed our image into the pattern, it wouldn't match the
         * pattern size, and a white margin would be left. To make the pattern
         * the same size as the image we calculate the image size 
         * based on its resolution. 
         * 
         * Retrieve the original image resolution:
         */
        resx = p.info_image(image, "resx", "");
        resy = p.info_image(image, "resy", "");
        
        /* Calculate the image dimensions for 72 dpi */
        if (resx > 0) {
        	imagewidth = imagewidth * 72 / resx;
        	imageheight = imageheight * 72 / resy;
        }

        /* Create a pattern using the retrieved image dimensions.
         * The painttype parameter must be set to 1 since a colorized
         * image is used (as opposed to an image mask).
         */
        pattern = p.begin_pattern(imagewidth, imageheight, imagewidth,
            imageheight, 1);
        p.fit_image(image, 0, 0, "");
        p.end_pattern();
        p.close_image(image);

        /* Start page */
        p.begin_page_ext(pagewidth, pageheight, "");
        
        /* Set a fill color and create and fill a rectangle with the dimensions
         * of the page. Encapsulate the setcolor() call with save() and 
         * restore() to be able to proceed with the original colors.
         */
        p.save();
        p.setcolor("fill", "pattern", pattern, 0, 0, 0);
        p.rect(0, 0, pagewidth, pageheight);
        p.fill();
        p.restore();

        /* Output some page contents */
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        p.setfont(font, 14);
        p.set_text_pos(20, 700);
        p.show("The page background consists of a small image pattern");
        p.continue_text("which will be output on the page repeatedly.");
        
        p.end_page_ext("");
        
        p.end_document("");

    	} catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
