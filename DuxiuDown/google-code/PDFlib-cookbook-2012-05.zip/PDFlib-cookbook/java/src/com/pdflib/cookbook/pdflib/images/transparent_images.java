/* $Id: transparent_images.java,v 1.2 2007/10/30 16:16:34 katja Exp $
 * Transparent images:
 * Create transparent images
 *
 * Display a colored background rectangle. Output two transparent background
 * images over that rectangle, then output a non-transparent image in the
 * foreground. Create transparency by applying an extended graphics
 * state with the "opacityfill" option set to a value less than 1.
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: image file
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class transparent_images
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "transparent_images.pdf";
    String title = "Transparent Images";

    pdflib p = null;
    
    String imagefile = "nesrin.jpg";
    int image, gstate, font;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.2 $");
        
        /* Load image */
        image = p.load_image("auto", imagefile, "");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the font; for PDFlib Lite: change "unicode" to "winansi" */
        font = p.load_font("Helvetica", "unicode", "");
        if (font == -1)
        throw new Exception("Error: " + p.get_errmsg());

        /* Start page 1 */
        p.begin_page_ext(842, 595, "");
        
        /* Draw a yellow background rectangle */
        p.setcolor("fill", "rgb", 1, 0.9, 0.58, 0);
        p.rect(0, 0, 421, 595);
        p.fill();
        
        /* Display some descriptive text */
        p.setcolor("fill", "gray", 0, 0, 0, 0);
        p.fit_textline("Two transparent background images with a " +
            "non-transparent image placed in the foreground", 50, 530, "font=" +
            font + " fontsize=18");
        
        /* Save the current graphics state. The save/restore of the current
         * state is not necessarily required, but it will help you get back to
         * a graphics state without any transparency.
         */
        p.save();
        
        /* Create an extended graphics state with transparency set to 50%, using
         * create_gstate() with the "opacityfill" option set to 0.5.
         */
        gstate = p.create_gstate("opacityfill=.5");
        
        /* Apply the extended graphics state */
        p.set_gstate(gstate);
        
        /* Display two images which will be transparent according to the
         * graphics state set.
         */
        p.fit_image(image, 0, 0, "boxsize={842 595} position={center bottom}");
        p.fit_image(image, 0, 0, "boxsize={842 595} position={center bottom} " +
            "scale=0.7");
          
        /* Restore the current graphics state */
        p.restore();
        
        /* Display the image again. It will not be transparent since the old
         * graphics state has been restored with no transparency set.
         */ 
        p.fit_image(image, 0, 0, "boxsize={842 595} position={center bottom} " +
            "scale=0.35");
        
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
