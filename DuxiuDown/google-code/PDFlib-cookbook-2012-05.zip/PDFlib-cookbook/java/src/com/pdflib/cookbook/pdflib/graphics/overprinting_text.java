/* $Id: overprinting_text.java,v 1.3 2007/10/06 21:20:27 katja Exp $
 * Overprinting text:
 * Create text which will overprint other page contents instead of knocking
 * it out
 *
 * Create an extended graphics state with the options
 * "overprintfill=true overprintmode=1".
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.graphics;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class overprinting_text
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "overprinting_text.pdf";
    String title = "Overprinting Text";

    pdflib p = null;
    
    int gstate, font;
 
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");
        
        /* Load the font; for PDFlib Lite: change "unicode" to "winansi" */
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Start page */
        p.begin_page_ext(400, 300, "");
        
        /* Draw a red background rectangle */
        p.setcolor("fill", "cmyk", 0, 1, 1, 0);
        p.rect(0, 0, 400, 300);
        p.fill();
        
        /* Save the current graphics state */
        p.save();
        
        /* Create an extended graphics state */
        gstate = p.create_gstate("overprintfill overprintmode=1");
        
        /* Apply the extended graphics state */
        p.set_gstate(gstate);
        
        /* Show some text which will overprint other page contents according to
         * the graphics state set
         */
        p.setfont(font, 36);
        p.setcolor("fill", "cmyk", 0, 0, 0, 1);
        p.set_text_pos(20, 200);
        p.show("overprinting text");
        
        /* Restore the current graphics state */
        p.restore();
               
        /* Show some text. It will not be overprinting since the old graphics
         * state has been restored with no overprinting set.
         */
        p.setfont(font, 36);
        p.setcolor("fill", "cmyk", 0, 0, 0, 1);
        p.set_text_pos(20, 100);
        p.show("text not overprinting");
        
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
