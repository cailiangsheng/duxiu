/* 
 * $Id: aes256_unicode_password.java,v 1.1 2010/01/26 09:57:51 stm Exp $
 * 
 * Demonstrate AES-256 encryption and Unicode passwords.
 * 
 * The file can only be opened with Acrobat 9 and later.
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 8
 * Required data: Norasi font
 */
package com.pdflib.cookbook.pdflib.general;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class aes256_unicode_password {
    public static void main(String argv[]) {
        final String outfile = "aes256_unicode_password.pdf";
        final String title = "AES-256 encryption and Unicode passwords";
        
        /* This is where the data files are. Adjust as necessary. */
        final String searchpath = "../input";
        
        pdflib p = null;

        try {
            p = new pdflib();

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            p.set_parameter("SearchPath", searchpath);
            
            /*
             * The password demonstrates some features of Unicode passwords:
             * 
             * - Characters outside the normal 8-bit character range (THAI
             *   CHARACTER KO KHAI and THAI CHARACTER KHO KAI)
             *   
             * - Normalization of Unicode passwords (LATIN SMALL LIGATURE FF
             *   and LATIN SMALL LIGATURE FI are normalized to "ff" and "fi")
             */
            final String thai_letters = "\u0E01\uu0E02";
            final String ligatures = "\uFB00 \uFB01";
            final String normalized_ligatures ="ff fi";
            
            final String password = thai_letters + " " + ligatures;
            final String normalized_password = thai_letters + " " 
                                        + normalized_ligatures;
 
            /*
             * To get AES-256 encryption the PDF version must be set to
             * PDF 1.7 extension level 3.
             */
            final String optlist = "compatibility=1.7ext3 "
                    + "masterpassword={" + password + "}";

            if (p.begin_document(outfile, optlist) == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.1 $");

            p.begin_page_ext(595, 842, "");

            final int font = p.load_font("Norasi", "unicode", "embedding");

            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.setfont(font, 24);

            p.set_text_pos(50, 700);
            p.show("AES-256 encryption and Unicode passwords");
            
            final String text =
                "This document produced by PDFlib is AES-256-encrypted. It "
                + "can only be opened by Acrobat 9 and later.\n\n"
                + "The master password of this document is:\n\n"
                + password
                + "\n\nUse cut&paste to enter the password into the Acrobat "
                + "prompt for changing the security settings of the document.\n\n"
                + "Because the password is normalized, it can also be "
                + "entered like this (note the decomposed ligatures):\n\n"
                + normalized_password;

            final int tf = p.add_textflow(-1, text, 
                "fontname=Norasi fontsize=18 encoding=unicode");
            if (tf == -1)
                throw new Exception("Error: " + p.get_errmsg());
            p.fit_textflow(tf, 50, 50, 500, 650, "");
            
            p.end_page_ext("");
            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
