/* $Id: glyph_availability.java,v 1.7 2010/02/12 14:30:56 stm Exp $
 * 
 * Glyph availability: Check the availability of glyphs in a font
 *
 * Load a font with "encoding=unicode". Then, for a specific Unicode character, 
 * output a row in a table containing the following information:
 *
 * 1) Font name
 * 2) Unicode codepoint and character name
 * 3) Glyph if available
 * 4) Glyph name if available
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 8
 * Required data: Font files. The sample looks for the font file "arialuni.ttf"
 * ("Arial Unicode MS"). Put this file into the "extra_input" directory.
 */

package com.pdflib.cookbook.pdflib.fonts;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

class glyph_availability {

    static private class testcase {
        testcase(String font_name, String font_optlist,
            char character, String character_desc) {
            this.font_name = font_name;
            this.font_optlist = font_optlist;
            this.character = character;
            this.character_desc = character_desc;
        }

        String font_name;
        String font_optlist;
        char character;
        String character_desc;
    }

    public static void main(String argv[]) {
        /* This is where the data files are. Adjust as necessary. */
        final String searchpath = "../input";
        /* Put extra fonts into the "extra_input" directory */
        final String extra_searchpath = "../extra_input";

        String outfile = "glyph_availability.pdf";
        String title = "Glyph Availability";

        String optlist;
        pdflib p = null;
        int i, table;
        final double llx = 50, lly = 50, urx = 800, ury = 550;
        String result;

        final String headers[] = { "Font name", "Unicode character", 
                                "Glyph", "Glyph name" };

        final testcase testcases[] = {
            new testcase("Helvetica", "", 'a', "LATIN LETTER A"),
            new testcase("ScheherazadeRegOT", "", '\u0646', "ARABIC LETTER NOON"),
            new testcase("arialuni", "", '\u0646', "ARABIC LETTER NOON"),
            new testcase("Helvetica", "", '\u0646', "ARABIC LETTER NOON"),
            new testcase("Helvetica", "", '\u2D33', "TIFINAGH LETTER YAG"),
            new testcase("GenI102", "",  '\u017A', "LATIN SMALL LETTER Z WITH ACUTE"),
            new testcase("Norasi", "", '\u017A', "LATIN SMALL LETTER Z WITH ACUTE"),
            new testcase("Norasi", "", '\u20AC', "EURO SIGN"),
        };

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);
            p.set_parameter("SearchPath", extra_searchpath);

            /*
             * This means that formatting and other errors will raise an
             * exception. This simplifies our sample code, but is not
             * recommended for production code.
             */
            p.set_parameter("errorpolicy", "exception");

            /* Set an output path according to the name of the topic */
            if (p.begin_document(outfile, "") == -1) {
                throw new Exception("Error: " + p.get_errmsg());
            }

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.7 $");

            table = -1;

            /* Table header */
            for (i = 0; i < headers.length; i++) {
                final int col = i + 1;

                optlist = "fittextline={fontname=Helvetica-Bold "
                    + "encoding=unicode fontsize=12} margin=4";
                table = p.add_table_cell(table, col, 1, headers[i], optlist);
            }

            /* Create a table with feature samples, one feature per table row */
            for (i = 0; i < testcases.length; i += 1) {
                final testcase testcase = testcases[i];
                final int row = i + 2;

                /*
                 * Try to load the fonts, output a row that shows the missing
                 * font if a font can't be loaded.
                 */
                final String error_optlist = "fittextline={fontname=Helvetica " 
                    + "encoding=unicode fontsize=12 fillcolor=red} "
                    + "margin=4";

                final String font_optlist = testcase.font_optlist
                                + " errorpolicy=return";

                final int font = p.load_font(testcase.font_name, "unicode",
                    font_optlist);
                if (font != -1) {
                    table = put_row(p, table, row, font, testcase);
                }
                else {
                    table = p.add_table_cell(table, 1, row,
                        testcase.font_name + ": font not available",
                        error_optlist);
                }
            }

            /*
             * Loop until all of the table is placed; create new pages as long
             * as more table instances need to be placed.
             */
            do {
                p.begin_page_ext(0, 0, "width=a4.height height=a4.width");

                optlist = "header=1 fill={{area=rowodd fillcolor={gray 0.9}}} "
                    + "stroke={{line=other}} ";

                /* Place the table instance */
                result = p.fit_table(table, llx, lly, urx, ury, optlist);

                if (result.equals("_error"))
                    throw new Exception("Couldn't place table: "
                        + p.get_errmsg());

                p.end_page_ext("");
            }
            while (result.equals("_boxfull"));

            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }

    /**
     * Output one row with information regarding one specific character
     * 
     * @param p
     *            the pdflib object
     * @param table
     *            the table handle
     * @param row
     *            the number of the current row
     * @param font
     *            the font handle for the original font
     * @param t
     *            the current test case
     *            
     * @return the table handle
     * 
     * @throws PDFlibException
     */
    static int put_row(pdflib p, int table, int row, int font, testcase t)
        throws PDFlibException {
        int col = 1;

        /*
         * Common option list for all columns except the "Actual glyph" column
         */
        final String common_optlist = "fittextline={fontname=Helvetica " 
            + "encoding=unicode fontsize=12} margin=4";

        /*
         * Column 1: Font name
         */
        table = p.add_table_cell(table, col++, row, t.font_name, common_optlist);

        /*
         * Column 2: Unicode value and name of Unicode character
         */
        final String uv = get_hex_notation(t.character);
        final String char_desc = uv + " (" + t.character_desc + ")";
        table = p.add_table_cell(table, col++, row, char_desc, common_optlist);

        /*
         * Determine whether a glyph is available, and if so, determine
         * the glyph name, if available.
         */
        final int gid = (int) p.info_font(font, "glyphid", "unicode=" + uv);

        String display_character;
        String gn;
        if (gid != -1) {
            display_character = Character.toString(t.character);

            final int gn_idx = (int) p.info_font(font, "glyphname",
                                                    "unicode=" + uv);
            if (gn_idx != -1) {
                gn = p.get_parameter("string", gn_idx);
            }
            else {
                gn = "n/a";
            }
        }
        else {
            display_character = "n/a";
            gn = "n/a";
        }

        /*
         * Column 3: Actual glyph, if available
         */
        final String testfont_optlist = "fittextline={font=" + font
                + " fontsize=12} margin=4";
        table = p.add_table_cell(table, col++, row, display_character,
                testfont_optlist);

        /*
         * Column 4: Glyph name
         */
        table = p.add_table_cell(table, col++, row, gn, common_optlist);

        return table;
    }

    /**
     * Get a string with the Unicode hex notation for a character.
     */
    static String get_hex_notation(char c) {
        final String leading_zeros = "0000";
        final String hex = Integer.toHexString((int) c).toUpperCase();
        final String hex_with_zeros = leading_zeros.substring(hex.length())
            + hex;
        return "U+" + hex_with_zeros;
    }
}
