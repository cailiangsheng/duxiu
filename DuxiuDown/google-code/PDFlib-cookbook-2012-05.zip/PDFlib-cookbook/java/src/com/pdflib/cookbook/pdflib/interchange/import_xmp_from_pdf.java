/* $Id: import_xmp_from_pdf.java,v 1.2 2009/07/13 11:32:32 rjs Exp $
 * Import XMP from PDF:
 * Retrieve the XMP metadata from an imported PDF document and write all
 * document-level XMP metadata to the output PDF 
 * 
 * Maintain existing XMP metadata when processing documents: Read the XMP 
 * stream from the imported document with the pCOS path "/Root/Metadata",
 * create a PVF file from the XMP and feed the document-level metadata to the
 * output document.
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document with XMP metadata
 */
package com.pdflib.cookbook.pdflib.interchange;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class import_xmp_from_pdf
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "import_xmp_from_pdf.pdf";
    String title = "Import XMP from PDF";

    pdflib p = null;
    String pdffile = "PDFlib-real-world.pdf";
    byte[] metadata = null;
    int indoc, pageno, endpage, page;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");
        
        /* Open the input PDF */
        indoc = p.open_pdi_document(pdffile, "");
        if (indoc == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Check if any document-level metadata exists in the input document */
        String objtype = p.pcos_get_string(indoc, "type:/Root/Metadata");
        if (objtype.equals("stream"))
        {
	    /* If document-level metadata exists retrieve it using the pCOS
	     * path "/Root/Metadata". (Similarly, you could retrieve any
	     * existing XMP metadata on page, font, or image level, etc. using
	     * the pCOS path "pages[...]/Metadata", "images[...]/Metadata",
	     * "fonts[...]/Metadata", etc.)
	     */
            metadata = p.pcos_get_stream(indoc, "", "/Root/Metadata");
        }

        if (metadata != null && metadata.length > 0)
	{
            /* If document-level metadata is available, store it in a
             * PDFlib virtual file (PVF)
             */
            p.create_pvf("/pvf/metadata", metadata, "");
                        
            /* Start the output document and copy the XMP metadata from the PVF
             * to it 
             */
            if (p.begin_document(outfile,
                "metadata={filename={/pvf/metadata}}") == -1)
                throw new Exception("Error: " + p.get_errmsg());
            
            p.delete_pvf("/pvf/metadata");
        }
        else
        {
            /* Start the output document without copying any metadata */
            if (p.begin_document(outfile, "") == -1)
                throw new Exception("Error: " + p.get_errmsg());
        }
         
        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.2 $");

        /* Retrieve the number of pages for the input document */
        endpage = (int) p.pcos_get_number(indoc, "length:pages");

        /* Loop over all pages of the input document */
        for (pageno = 1; pageno <= endpage; pageno++)
        {
            page = p.open_pdi_page(indoc, pageno, "");

            if (page == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Dummy page size; will be adjusted later */
            p.begin_page_ext(10, 10, "");

            /* Place the imported page without performing
             * any changes on the output page
             */
            p.fit_pdi_page(page, 0, 0, "adjustpage");
            
            p.end_page_ext("");

            p.close_pdi_page(page);
        }
 
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
