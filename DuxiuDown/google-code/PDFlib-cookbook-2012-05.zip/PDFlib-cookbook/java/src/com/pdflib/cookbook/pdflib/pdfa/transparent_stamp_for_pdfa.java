/* $Id: transparent_stamp_for_pdfa.java,v 1.5 2011/08/01 14:44:29 stm Exp $
 * Transparent stamp for PDF/A:
 * Apply a transparent stamp to an existing PDF/A document while maintaining
 * PDF/A conformance.
 * 
 * Import all pages from an existing PDF/A document and place a stamp on the
 * page. The stamp is filled with a pattern color, where the pattern consists of
 * a bitmap. The bitmap is used as a mask to create a certain percentage of
 * transparency. This is required since real transparency is not allowed in
 * PDF/A. Transparency by pattern color is PDF/A compatible, so we use it to
 * apply a transparent stamp on a PDF/A document while maintaining PDF/A
 * conformance.
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document
 */
package com.pdflib.cookbook.pdflib.pdfa;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class transparent_stamp_for_pdfa
{
    public static void main (String argv[])
    {
        /* This is where the data files are. Adjust as necessary. */
        String searchpath = "../input";
        String outfile = "transparent_stamp_for_pdfa.pdf";
        String title = "Transparent Stamp for PDF/A";

        pdflib p = null;

        String pdffile = "PLOP-datasheet-PDFA-1b.pdf";
        int indoc, pageno, endpage, page, font, pattern;
        double w;
        double ret;
        String res;
        int image;

        /* data set for our halftoning bitmap */
        int data[][] = {
        {   0x00, 0x00,  /* 30% */
            0x00, 0x00,
            0x00, 0x00,
            0x03, 0xC0,
            0x07, 0xE0,
            0x0F, 0xF0,
            0x1F, 0xF8,
            0x1F, 0xF8,
    
            0x1F, 0xF8,
            0x1F, 0xF8,
            0x0F, 0xF0,
            0x07, 0xE0,
            0x03, 0xC0,
            0x00, 0x00,
            0x00, 0x00,
            0x00, 0x00,
        },
        {   0x00, 0x00, /* 20% */
            0x00, 0x00,
            0x00, 0x00,
            0x00, 0x00,
            0x03, 0xC0,
            0x07, 0xE0,
            0x0F, 0xF0,
            0x0F, 0xF0,
    
            0x0F, 0xF0,
            0x0F, 0xF0,
            0x07, 0xE0,
            0x03, 0xC0,
            0x00, 0x00,
            0x00, 0x00,
            0x00, 0x00,
            0x00, 0x00,
        }};
    
        int ht = 1; /* index in halftone array */

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            check_pdflib_version(p, 7, 0, 4);

            if (p.begin_document(outfile, "pdfa=PDF/A-1b:2005") == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.5 $");

            /*
             * Open the input PDF. This must be done before creating the pattern
             * because the output intent must be set before defining the
             * pattern.
             */
            indoc = p.open_pdi_document(pdffile, "");
            if (indoc == -1)
                throw new Exception("Error: " + p.get_errmsg());

            endpage = (int) p.pcos_get_number(indoc, "length:pages");

            /*
             * Since the input document contains its own output intent retrieve
             * the output intent from the input document and copy it to the
             * output document.
             */
            res = p.pcos_get_string(indoc, "type:/Root/OutputIntents");
            if (res.equals("array")) {
                ret = p.process_pdi(indoc, -1, "action=copyoutputintent");
                if (ret == -1)
                    throw new Exception("Error: " + p.get_errmsg());
            }

            /*
             * Define a bitmap pattern based on an image mask. We scale down
             * the image to provide a smoother appearance on screen.
             */
            byte[] bitmap = new byte[data[ht].length];
            for (int j = 0; j < data[ht].length; j++)
                bitmap[j] = (byte) data[ht][j];

            p.create_pvf("/pvf/image/bitmap", bitmap, "");

            image = p.load_image("raw", "/pvf/image/bitmap",
                    "bpc=1 components=1 height=16 width=16 invert mask");

            if (image == -1)
                throw new Exception("Error: " + p.get_errmsg());

            w = (double) 16 / 32;
            pattern = p.begin_pattern(w, w, w, w, 1);

            p.fit_image(image, 0, 0, "scale=" + (double) 1 / 32);

            p.end_pattern();

            p.close_image(image);

            /* Loop over all pages of the input document */
            for (pageno = 1; pageno <= endpage; pageno++) {
                page = p.open_pdi_page(indoc, pageno, "");

                if (page == -1)
                    throw new Exception("Error: " + p.get_errmsg());

                /* Dummy page size; will be adjusted later */
                p.begin_page_ext(10, 10, "");

                /*
                 * Place the imported page on the output page, and adjust the
                 * page size.
                 */
                p.fit_pdi_page(page, 0, 0, "adjustpage");

                /*
                 * Load the font for the stamp.
                 */
                font = p.load_font("DejaVuSerif", "unicode", "embedding");

                if (font == -1)
                    throw new Exception("Error: " + p.get_errmsg());

                /* Place the stamp, filled with the pattern color */
                p.setcolor("fill", "pattern", pattern, 0, 0, 0);

                p.fit_textline("PUBLISHED", 20, 20, "font=" + font
                        + " fontsize=1 boxsize={550 800} stamp=ll2ur");

                p.close_pdi_page(page);

                p.end_page_ext("");
            }

            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                    + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }
    
    /**
     * Check whether the required minimum PDFlib version is available
     * 
     * @param p
     *            the pdflib object
     * @param major
     *            PDFlib major version number
     * @param minor
     *            PDFlib minor version number
     * @param revision
     *            PDFlib revision number
     * 
     * @throws PDFlibException
     * @throws Exception
     */
    private static void check_pdflib_version(pdflib p, int major, int minor,
            int revision) throws PDFlibException, Exception {
        final int actualMajor = (int) p.get_value("major", 0);
        final int actualMinor = (int) p.get_value("minor", 0);
        final int actualRevision = (int) p.get_value("revision", 0);

        /* Required minimum PDFlib version */
        final int requiredVersion = major * 100 + minor * 10 + revision;
        final int actualVersion = actualMajor * 100 + actualMinor * 10
                + actualRevision;

        if (actualVersion < requiredVersion) {
            throw new Exception("Error: PDFlib " + major + "." + minor + "."
                    + revision + " or above is required");
        }
    }
}
