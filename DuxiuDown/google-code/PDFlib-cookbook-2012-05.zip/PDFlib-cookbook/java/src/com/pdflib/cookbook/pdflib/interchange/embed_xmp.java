/* $Id: embed_xmp.java,v 1.2 2009/07/13 11:32:32 rjs Exp $
 * Embed XMP:
 * Embed custom XMP metadata in a document
 * 
 * Use the "metadata" option of begin_document() to read XMP metadata from an
 * XMP file and embed it in the output document.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: XMP file
 */
package com.pdflib.cookbook.pdflib.interchange;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class embed_xmp
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "embed_xmp.pdf";
    String title = "Embed XMP";

    pdflib p = null;
    String xmpfile = "simple.xmp";
    int font;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");
        
        /* Start the document with an XMP file supplied, containing a few
         * commonly used XMP properties. The XMP metadata will be read from the
         * file and embedded in the document. PDFlib will merge several
         * internally generated entries into the user-supplied XMP, e.g.
         * xmp:CreateDate. 
         */
        if (p.begin_document(outfile, 
            "metadata={filename={" + xmpfile + "}}") == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.2 $");
        
        font = p.load_font("Helvetica", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Start page */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        
        p.setfont(font, 12);
        
        p.fit_textline("XMP metadata is read from an XMP file and embedded " +
            "in the document.", 20, 600, "");
        
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
