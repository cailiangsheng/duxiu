/*
 * $Id: alpha_channel.java,v 1.1 2010/01/28 14:05:14 stm Exp $
 *
 * Demonstrate the use of an integrated alpha channel (aka soft masks aka 
 * transparency) in images. This works with TIFF and PNG images.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 8
 * Required data: image file
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class alpha_channel {

    public static void main(String argv[]) {
        /* This is where the data files are. Adjust as necessary. */
        final String searchpath = "../input";
        final String outfile = "alpha_channel.pdf";
        final String title = "Add Image With Alpha Channel";

        final String imagefile = "magnolia.png";
        final double pg_width = 595;
        final double pg_height = 842;

        final String bg_text = 
            "This text is visible through the transparent image.";
        final int repeat_text = 40;
        
        pdflib p = null;

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            if (p.begin_document(outfile, "") == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.1 $");

            /* Load the font */
            int font = p.load_font("Helvetica", "unicode", "");
            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Load the image */
            int image = p.load_image("auto", imagefile, "");
            if (image == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Define size and position of image box. */
            final double box_width = pg_height / 2;
            final double box_height = pg_width / 2;
            final double img_llx = (pg_width - box_width) / 2;
            final double img_lly = (pg_height - box_height) / 2;
            
            /* Position and size of headline box */
            final double headline_displacement = 40;
            final double headline_llx = img_llx;
            final double headline_lly = 
                        img_lly + box_height + headline_displacement;
            final double headline_width = box_width;
            final double headline_height = headline_displacement;
            
            /* Start page */
            p.begin_page_ext(pg_width, pg_height, "");

            /* Create a headline */
            p.fit_textline(
                "Place an image with an alpha channel over a background", 
                headline_llx, headline_lly, 
                "boxsize={" + headline_width + " " + headline_height + "} "
                + "font=" + font + " fontsize=18 position=center");
            
            /*
             * Put a text in the background, covering the same area as the
             * image.
             */
            int tf = -1;
            for (int i = 0; i < repeat_text; i += 1) {
                tf = p.add_textflow(tf, bg_text, "font=" + font 
                        + " fontsize=12 alignment=justify");
            }

            /* Place the textflow */
            p.fit_textflow(tf, img_llx, img_lly, 
                img_llx + box_width, img_lly + box_height, "");
            p.delete_textflow(tf);
            
            /* Place the image over the textflow */
            p.fit_image(image, img_llx, img_lly, 
                "boxsize={" + box_width + " " + box_height + "} "
                + "fitmethod=meet showborder position=center");
            p.close_image(image); 

            p.end_page_ext("");
            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.toString());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
