/* $Id: type3_bitmaptext.java,v 1.8 2008/01/15 12:46:09 katja Exp $
 * Type 3 bitmap text:
 * Create a simple Type 3 font from image data
 *
 * Use the "inline" option of load_image() for loading glyph bitmaps.
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: image files
 */
package com.pdflib.cookbook.pdflib.fonts;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class type3_bitmaptext
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "type3_bitmaptext.pdf";
    String title = "Type 3 Bitmap Text";

    pdflib p = null;
    int image;
    int bitmapfont;
    String optlist = "inline bpc=1 components=1 height=16 width=8 mask invert";

    int data[][] =
    {{0x00, 0x00, 0x00, 0x00, 0x00, 0x78, 0x84, 0x04, 0x7C, 0x84, 0x84, 0x8C,
      0x76, 0x00, 0x00, 0x00}, /* "a" */
     {0x00, 0x00, 0xC0, 0x40, 0x40, 0x5C, 0x62, 0x42, 0x42, 0x42, 0x42, 0x62,
     0xDC, 0x00, 0x00, 0x00},  /* "b" */
     {0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x42, 0x40, 0x40, 0x40, 0x42, 0x42,
      0x3C, 0x00, 0x00, 0x00}}; /* "c" */

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.8 $");

        /* From the data defining three glyphs, create three PVFs
         * "/pvf/font/bitmap0" ... "/pvf/font/bitmap2"
         */
        byte [] glyphdef = new byte[data[0].length];

        for (int i=0; i < 3; i++) {
            for (int j=0; j < data[0].length; j++)
                glyphdef[j] = (byte) data[i][j];

            p.create_pvf("/pvf/font/bitmap" + i, glyphdef, "");
        }

        /* Create the "BitmapFont" font */
        p.begin_font("BitmapFont", 1/16.0, 0, 0, 1/16.0, 0, -3/16.0, "");

        /* Start the glyph definition for "a" */
        p.begin_glyph("a", 8, 0, 0, 8, 16);

        /* Load the bitmap data for the glyph from the PVF.
         * The "inline" option is provided so that load_image() will internally
         * perform the equivalent of fit_image(image, 0, 0, "") and
         * close_image(image).
         */
        image = p.load_image("raw", "/pvf/font/bitmap0", optlist);
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.end_glyph();

        /* Define the glyph "b" */
        p.begin_glyph("b", 8, 0, 0, 8, 16);

        image = p.load_image("raw", "/pvf/font/bitmap1", optlist);
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.end_glyph();

        /* Define the glyph "c" */
        p.begin_glyph("c", 8, 0, 0, 8, 16);

        image = p.load_image("raw", "/pvf/font/bitmap2", optlist);
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.end_glyph();

        /* The .notdef (fallback) glyph should be contained in all Type 3
         * fonts to avoid problems with some PDF viewers. It is usually
         * empty.
         */
        p.begin_glyph(".notdef", 8, 0, 0, 0, 0);
        p.end_glyph();

        p.end_font();

        p.begin_page_ext(0, 0, "width=200 height=300");

        /* Load the new "BitmapFont" font */
        bitmapfont = p.load_font("BitmapFont", "winansi", "embedding");
        if (bitmapfont == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Output the characters "a", "b", and "c" */
        p.fit_textline("a", 70, 200, "font=" + bitmapfont + " fontsize=36");
        p.fit_textline("b", 70, 150, "font=" + bitmapfont + " fontsize=36");
        p.fit_textline("c", 70, 100, "font=" + bitmapfont + " fontsize=36");

        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
