/* $Id: multi_page_tiff.java,v 1.5 2012/05/07 08:42:23 stm Exp $
 * Multi-page TIFF to PDF converter
 * 
 * Convert an input TIFF image containing one or more frames to PDF.
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: multi-page TIFF image
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class multi_page_tiff
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "multi_page_tiff.pdf";
    String title = "Multi-page TIFF";

    pdflib p = null;
    String imagefile = "multi_page.tif";
    int font, image, frame;
    int x = 50, y = 700; 
   
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.5 $");
        
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
        	throw new Exception ("Error: " + p.get_errmsg());
        
        /* Loop over all frames of the multi-page TIFF image */
        for (frame = 1; /* */ ; frame++)
        {
        	/* Load the next frame of the image */
            image = p.load_image("tiff", imagefile, "page=" + frame);
            if (image == -1)
            {
                if (frame == 1)
                    /* Image not found */
                    throw new Exception("Error: " + p.get_errmsg());
                else
                    /* no more frames available */
                    break;
            }
            
            /* Start page and place the frame on the page,
	     * placed at the bottom center.
	     */
            p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
            p.fit_image(image, 0.0, 0.0, "adjustpage");
            p.close_image(image);
            
            /* Output the number of the frame */
            p.fit_textline("Frame " + frame + " of the TIFF image", x, y,
                "font= " + font + " fontsize=12");
            p.end_page_ext("");
        }
   
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
