/* $Id: text_as_clipping_path.java,v 1.2 2007/10/04 15:07:15 katja Exp $
 * Text as clipping path:
 * Output text filled with an image 
 *  
 * Use various text rendering modes to place an image clipped by some text
 * outlines.
 * Use the "textrendering=7" parameter to add text to the clipping path. Then
 * place an image clipped by that path.
 * Use "textrendering=5" to stroke text and add it to the clipping path. Then
 * place an image clipped by that path.
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: image file
 */
package com.pdflib.cookbook.pdflib.text_output;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class text_as_clipping_path
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "text_as_clipping_path.pdf";
    String title = "Text as Clipping Path";

    pdflib p = null;
    
    String imagefile = "nesrin.jpg";
    int font, image;
 
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
        throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.2 $");

        /* Load the font; for PDFlib Lite: change "unicode" to "winansi" */
        font = p.load_font("Helvetica-Bold", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the image */
        image = p.load_image("auto", imagefile, "");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Start an A4 landscape page */
        p.begin_page_ext(0, 0, "width=a4.height height=a4.width");
        
        /* Save the current graphics state */
        p.save();
        
        /* Set the text rendering mode to "add text to the clipping path" */
        p.set_value("textrendering", 7);
               
        /* Output some text. The text outlines will not actually be output but 
         * be added to the clipping path instead. Note that with a text
         * rendering mode of 7, just the simple text output functions can be
         * used. 
         */ 
        p.setfont(font, 250);
        p.set_text_pos(30, 250);
        p.show("Hello!");
        
        /* Place the image */
        p.fit_image(image, 0.0, 0.0, "boxsize={842 595} fitmethod=entire");
                
         
        /* Restore the current graphics state */
        p.restore();
        
        /* Save the current graphics state */
        p.save();
        
        
        /* Set the text rendering mode to "stroke text and add it to the
         * clipping path"
         */
        p.set_value("textrendering", 5);
               
        /* Output some text. The text outlines will not actually be output but 
         * be added to the clipping path instead. Note that with a text
         * rendering mode of 5, just the simple text output functions can be
         * used. 
         */ 
        p.setfont(font, 200);
        
        p.setcolor("stroke", "rgb", 0.1, 0.1, 0.1, 0);
        p.setlinewidth(8);
        
        p.set_text_pos(100, 50);
        p.show("Hello!");
        
        /* Place the image */
        p.fit_image(image, 0.0, 0.0, "boxsize={842 595} fitmethod=entire");
                
        p.close_image(image);
              
        /* Restore the current graphics state */
        p.restore();
        
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
