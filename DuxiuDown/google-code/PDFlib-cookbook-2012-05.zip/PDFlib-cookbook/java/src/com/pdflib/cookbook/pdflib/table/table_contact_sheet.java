/* $Id: table_contact_sheet.java,v 1.2 2008/07/09 14:58:38 rjs Exp $
 * Table contact sheet:
 * Create a contact sheet with photos and their labels
 * 
 * Create a table and place a number of photos in it. For each photo, an image
 * is placed in one cell, and a text label is placed in the cell below. 
 *  
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.table;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class table_contact_sheet
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "table_contact_sheet.pdf";
    String title = "Table Contact Sheet";
    
    pdflib p = null;

    int i, j, row, col, tbl=-1, image=-1, regularfont, boldfont;
    final double fontsize = 12;
    String result;
    final double pagewidth = 842, pageheight = 595;
  
    /* table coordinates */
    final int llx = 50, urx = (int) pagewidth - llx;
    final int lly = 80, ury = (int) pageheight - lly;
    
    final int yheading = ury + 2 * 15;
   
    /* fixed number of table columns, variable number of rows */
    final int nocols = 5;

    /* column width for all columns */
    final int cw = 100;
    
    /* row height for image rows and text rows */
    final double img_rowheight = 100;
    final double txt_rowheight = 30;
    
    /* margins for image and text cells */
    final int img_margin = 6, txt_margin = 6;
      
    final String imagefiles [] = {
        "cambodia_angkor_thom.jpg",
        "cambodia_angkorwat1.jpg",
        "cambodia_angkorwat2.jpg",
        "cambodia_banteay_samre.jpg",
        "cambodia_bayon1.jpg",
        "cambodia_bayon2.jpg",
        "cambodia_bayon3.jpg",
        "cambodia_neak_pean.jpg",
        "cambodia_preah_khan1.jpg",
        "cambodia_preah_khan2.jpg",
        "cambodia_preah_khan3.jpg",
        "cambodia_preah_khan4.jpg",
        "cambodia_pre_rup1.jpg",
        "cambodia_pre_rup2.jpg",
        "cambodia_woman.jpg",
        "cambodia_bayon1.jpg",
        "cambodia_bayon2.jpg",
        "cambodia_bayon3.jpg",
        "cambodia_neak_pean.jpg",
        "cambodia_preah_khan1.jpg",
        "cambodia_preah_khan2.jpg",
        "cambodia_preah_khan3.jpg",
        "cambodia_preah_khan4.jpg",
        "cambodia_pre_rup1.jpg",
        "cambodia_pre_rup2.jpg",
        "cambodia_woman.jpg",
        "cambodia_angkorwat2.jpg",
        "cambodia_banteay_samre.jpg",
        "cambodia_bayon1.jpg",
        "cambodia_bayon2.jpg",
        "cambodia_bayon3.jpg",
        "cambodia_neak_pean.jpg",
        "cambodia_preah_khan1.jpg",
        "cambodia_preah_khan2.jpg",
        "cambodia_preah_khan3.jpg",
        "cambodia_preah_khan4.jpg",
        "cambodia_pre_rup1.jpg"
    };
    
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);
        
        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.2 $");

        /* Load the bold and regular styles of a font */
        boldfont = p.load_font("Helvetica-Bold", "unicode", "");
        if (boldfont == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        regularfont = p.load_font("Helvetica", "unicode", "");
        if (regularfont == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Start the output page */
        p.begin_page_ext(pagewidth, pageheight, "");

        /* Output the heading */
        p.setfont(boldfont, fontsize);
        p.fit_textline("Contact Sheets", llx, yheading, "");
 
        
        /* ------------------------------------------------------------------
         * For each photo add a cell containing an image and a text line with
         * the image file name
         * ------------------------------------------------------------------
         */
        
        /* Loop over all photos */
        col = 1; row = 1;
               
        for (i = 0; i < imagefiles.length; i++) {
            image = -1;
            
            /* Load the photo */
            image = p.load_image("auto", imagefiles[i], "");
            if (image == -1)
                throw new Exception("Error: " + p.get_errmsg());
            
            /* Add the cell containing the image.
             * 
             * "fitmethod=auto" scales the image so that it entirely fits into
             * the cell while preserving its aspect ratio.
             * "rowjoingroup" keeps image and text together on the same page. 
             */
            String img_opts = 
                " image=" + image + " fitimage={fitmethod=auto}" +
                " colwidth=" + cw + " rowheight=" + img_rowheight +
                " margin=" + img_margin + 
                " rowjoingroup=group" + i;
            
            tbl = p.add_table_cell(tbl, col, row, "", img_opts);
            if (tbl == -1)
                throw new Exception("Error adding cell: " + p.get_errmsg());
            
            /* Add the cell containing the text with the image file name.
             * 
             * "fitmethod=auto" scales the text so that it entirely fits into
             * the cell. Note that if this option is not used the cell width 
             * will be increased until the text fits completely into the cell.
             * "rowjoingroup" keeps image and text together on the same page.
             */
            String txt_opts = 
                "fittextline={font=" + regularfont + " fitmethod=auto" +
                " fontsize=9 fillcolor={gray 1} position={center}}" +
                " colwidth=" + cw + " rowheight=" + txt_rowheight +
                " margin=" + txt_margin +
                " rowjoingroup=group" + i;
            
            tbl = p.add_table_cell(tbl, col, row + 1, imagefiles[i], txt_opts);
            if (tbl == -1)
                throw new Exception("Error adding cell: " + p.get_errmsg());
            
            if (col < nocols) {
                col++;
            }
            else { 
                col = 1; row += 2;
            }
        } /* for */
                
             
        /* ------------------------------------
         * Place the table on one or more pages
         * ------------------------------------
         */
        
        /* Prepare the option list for fitting the table.
         * The "stroke" option will stroke every vertical line and every
         * second horizontal line in white with a line width of 0.3.
         * The "fill" option fills the complete table with a dark gray.
         */
        String stroke_opts = 
            "stroke={{line=vertother strokecolor={gray 1} linewidth=0.3}";
        
        for (i = 0, j = 2; i < imagefiles.length; i += nocols, j+=2) {
            stroke_opts +=
                " {line=hor" + j + " strokecolor={gray 1} linewidth=0.3}";
        }
        stroke_opts += "} ";
        
        String fill_opts = "fill={{area=table fillcolor={rgb 0.1 0.1 0.1}}}";
        
        String fittab_opts = stroke_opts + fill_opts; 
                  
        /* Loop until all of the table is placed; create new pages as long as
         * more table instances need to be placed
         */
        do {
            /* Place the table instance */
            result = p.fit_table(tbl, llx, lly, urx, ury, fittab_opts);

            if (result.equals("_error") || result.equals("_boxempty"))
                throw new Exception ("Couldn't place table: " +
                    p.get_errmsg());
            
            /* Start a new page */
            if (result.equals("_boxfull")) {
                p.end_page_ext("");
                p.begin_page_ext(pagewidth, pageheight, "");
            }
        } while (result.equals("_boxfull") || result.equals("break"));
        
        p.end_page_ext("");
       
        p.end_document("");
      
        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.toString());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
