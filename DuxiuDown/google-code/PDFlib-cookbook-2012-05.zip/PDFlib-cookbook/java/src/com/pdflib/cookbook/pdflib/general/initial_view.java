/* $Id: initial_view.java,v 1.6 2007/10/30 16:16:34 katja Exp $
 * Initial view:
 * Define the initial viewing properties for a document, such as zoom, page
 * number, navigation tab, or title bar
 * 
 * Define to open the document on page 2 using a fixed window size with a zoom
 * of 300% and the page displayed with the coordinates 720,100 on the top left.
 * In addition, show the Bookmarks navigation pane and the document title in 
 * the title bar of Acrobat.
 * 
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.general;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class initial_view
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "initial_view.pdf";
    String title = "Initial View";

    pdflib p = null;
    String optlist;
    int font;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");
        
        /* Open the document on page 2 using a fixed window size with
         * a zoom of 300% and the page displayed with the coordinates
         * 720,100 on the top left. In addition, show the "Title" document info
         * in Acrobat's title bar and show the "Bookmarks" navigation pane. 
         */
        optlist = "destination={page=2 type=fixed zoom=3 top=720 left=100} " +
                  "viewerpreferences=displaydoctitle openmode=bookmarks ";

        if (p.begin_document(outfile, optlist) == -1)
        throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.6 $");
        
        font = p.load_font("Helvetica", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
 
        /* Start page 1 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        
        /* Create a bookmark for jumping on that page */
        p.create_bookmark("Page 1", "");
        
        p.fit_textline("This is page 1", 100, 700, "font=" + font +
            " fontsize=20");
        
        p.end_page_ext("");
        
        /* Start page 2 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        
        /* Create a bookmark for jumping on that page */
        p.create_bookmark("Page 2", "");
        
        p.fit_textline("Page 2 is displayed with this text", 100, 700, "font=" +
            font + " fontsize=18");
        p.fit_textline("moved to the top left and a zoom", 100, 660, "font=" +
            font + " fontsize=18");
        p.fit_textline("of 300% when opening the document", 100, 620, "font=" +
            font + " fontsize=18");
        
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
