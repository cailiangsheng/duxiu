/* $Id: control_nexpress_trays.java,v 1.1 2008/04/18 20:33:30 katja Exp $
 * Control NexPress trays:
 * For NexPress digital color printing machines, create some special kind of
 * annotations to control the input tray.
 * 
 * Use the "custom" option of create_annotation() to create a "Stamp" annotation
 * with NexPress-specific custom extensions.   
 * The "P" in "PDF" means "Portable", which excludes the use of device-specific
 * parameters such as tray control. This technique is not really in the spirit
 * of portable PDF documents, but NexPress digital printing machines expect it
 * this way nevertheless.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.interchange;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class control_nexpress_trays
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "control_nexpress_trays.pdf";
    String title = "Control NexPress trays";

    pdflib p = null;
    int font;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");
        
        /* Start the document */
        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Set document info entries */
        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.1 $");
        
        /* Load font */
        font = p.load_font("Helvetica", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Start page */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        
        /* Set font */
        p.setfont(font, 12);
        
        /* Output some descriptive text */
        p.fit_textline("Use the \"custom\" option of create_annotation() to " +
             "create a \"Stamp\" annotation with", 20, 600, "");
        p.fit_textline("NexPress-specific custom extensions in the document.",
            20, 580, "");
        
        /* Create a "Stamp" annotation with NexPress-specific custom 
         * extensions. 
         * Some names which can be used in the "Name" key for tray selection:
         * SubstrateTypeCover, SubstrateTypeInsert,
         * SubstrateTypeInsert1 ... SubstrateTypeInsert9.
         * More details are available in the printer-specific documentation.
         */
        String optlist =
            "custom={{key=Open type=boolean value=false} " +
            "{key=Name type=name value=SubstrateTypeCover} " +
            "{key=Subj type=string value={Cover}}} " +
            "contents={Stamp Annotation for tray selection}";

        p.create_annotation(50, 500, 150, 550, "Stamp", optlist);
        
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
