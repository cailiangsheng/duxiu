/* $Id: form_tab_order.java,v 1.3 2007/10/30 16:16:32 katja Exp $
 * Form tab order:
 * Define the position of each form field in the tab order, i.e. when the user
 * presses the "Tab" key. 
 * 
 * By default the tab order of fields will be implicitly defined according to
 * their creation order. Using the "taborder" option another tab order can
 * be defined. Create a matrix of text fields row by row but define the tab
 * order column by column.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.interactive;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class form_tab_order
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary */
    String searchpath = "../input";
    String outfile = "form_tab_order.pdf";
    String title = "Form Tab Order";
    
    pdflib p = null;

    String optlist;
    int font, i, j, tab;
    double width=130, height=30, llx = 10, lly = 600;

    try {
        p = new pdflib();

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        p.set_parameter("SearchPath", searchpath);

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");

        font = p.load_font("Helvetica", "winansi", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Start page */
        p.begin_page_ext(0, 0, " width=a4.width height=a4.height");
        
        p.setfont(font, 14);
        p.fit_textline("Press \"Tab\" to move from one field to the next in " +
            "the tab order defined.", llx, lly, "");
        
        /* Create a matrix of text fields row by row but define the tab order
         * column by column (taborder=...). Each text fields show its position
         * in the tab order (currentvalue={...}).
         */
        optlist = "backgroundcolor={rgb 0.95 1 0.95} bordercolor={gray 0} " +
            "alignment=center font=" + font + " fontsize=18";
        
        lly-= 50;
        
        for (i = 1; i <= 3; i++) {
            for (j = 1, tab=i; j <= 3; j++, tab+=3) {
                p.create_field(llx, lly, llx + width, lly + height, 
                    "field" + tab, "textfield", optlist + " taborder=" + tab +
                    " currentvalue={tab position " + tab + "}");
                llx+=width + 20;
            }
            llx = 10;
            lly -= height + 30;
        }

        p.end_page_ext("");
        
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
