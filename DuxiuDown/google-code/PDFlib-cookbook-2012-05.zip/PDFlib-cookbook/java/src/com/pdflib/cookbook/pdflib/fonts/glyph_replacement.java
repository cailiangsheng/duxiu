/* $Id: glyph_replacement.java,v 1.4 2007/12/03 11:01:59 katja Exp $
 * Glyph replacement:
 * Show the effects of glyph substitution in case of glyphs missing in the font
 * 
 * Load the font and specify a replacement character to be used to output
 * missing glyphs.
 * Demonstrate various notations to output the Euro sign as U+20AC which is
 * available in the font.
 * Then, various notations to output the ligature "ffi" are shown, the glyph of
 * which is available in the font.
 * Output the glyph for an alternative g which is available in the font.
 * Output the glyph for an alternative s which is not available in the font. 
 * Output the glyph for the ligature "st" which is not available in the font. 
 * Use the "glyphcheck=replace" or "glyphcheck=none" option to determine if the
 * missing glyph will be replaced. Depending on the "glyphcheck" setting the
 * ligature "st" will be replaced by the two characters "s" and "t".
 * Output the Ohm glyph which is not available in the font. Depending on the
 * "glyphcheck" setting it will be replaced by the Omega character.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: font file
 */
package com.pdflib.cookbook.pdflib.fonts;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class glyph_replacement
{
public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "glyph_replacement.pdf";
    String title = "Glyph Replacement";

    pdflib p = null;
    int gfont, hfont, hbfont, x=30, x2=180, x3=360, x4=520, y=550, yoff=30;
    String inp, repl, norepl;
   
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);
        
        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
        throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.4 $");
        
        /* Load the font "Gentium-Italic" (see http://scripts.sil.org/gentium)
         * with "unicode" encoding.
         * "replacementchar=?" defines a question mark to be used for glyph
         * substitution in case of a missing glyph.
         */
        gfont = p.load_font("GenI102", "unicode", "replacementchar=?");
        if (gfont == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the Helvetica font */
        hfont = p.load_font("Helvetica", "unicode", "");
        if (hfont == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Load the Helvetica-Bold font */
        hbfont = p.load_font("Helvetica-Bold", "unicode", "");
        if (hbfont == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        
        /* Start page */
        p.begin_page_ext(0, 0, "width=a4.height height=a4.width");
               
        
        /* Define three option lists for fit_textline().
         * The "inp" option list is just for descriptive text.
         * The "repl" option list enables the interpretation of character 
         * references using "charref" and uses glyph substitution which is 
         * enabled by default ("glyphcheck=replace").
         * The second option list enables the interpretation of character 
         * references using "charref" but explicitly disables glyph 
         * substitution. Alternatively, glyph substitution can be disabled
         * with p.set_parameter("glyphcheck", "none");
         */
        inp = "font=" + hfont + " fontsize=14";
        repl = "charref font=" + gfont + " fontsize=22";
        norepl = "charref glyphcheck=none font=" + gfont + " fontsize=22";
        
        /* Output some descriptive header lines for the input, output, and
         * remark column
         */
        p.fit_textline("Glyphs in the Gentium-Italic font", x, y, 
            "font=" + hbfont + " fontsize=16");
        String opts = " underline underlinewidth=1";
        p.fit_textline("Input", x, y-=2*yoff, inp + opts);
        p.fit_textline("Output", x2, y, inp + opts);
        p.fit_textline("Remark", x4, y, inp + opts);
        p.fit_textline("glyphcheck=replace", x2, y-=yoff, inp + opts);
        p.fit_textline("glyphcheck=none", x3, y, inp + opts);
        
        
        /* ------------------------------------------------------------------
         * Use various notations to output the Euro symbol as U+20AC which is
         * available in the font.
         * ------------------------------------------------------------------ 
         */
        
        /* Java Unicode notation, 
         * The first string "\\u20AC" is a descriptive text and results in an 
         * output of "\u20AC" since the two slashes are resolved by the Java
         * compiler to one slash. 
         */
        p.fit_textline("\\u20AC", x, y-=yoff, inp);  
        p.fit_textline("\u20AC", x2, y, repl);       
        p.fit_textline("\u20AC", x3, y, norepl);
        p.fit_textline("selected glyph available in the font", x4, y, inp);
        
        /* Character reference in HTML style with hexadecimal number */
        p.fit_textline("&#x20AC;", x, y-=yoff, inp);
        p.fit_textline("&#x20AC;", x2, y, repl);
        p.fit_textline("&#x20AC;", x3, y, norepl);
        p.fit_textline("selected glyph available in the font", x4, y, inp);
        
        /* Character reference in HTML style with decimal number */
        p.fit_textline("&#8364;", x, y-=yoff, inp);
        p.fit_textline("&#8364;", x2, y, repl);
        p.fit_textline("&#8364;", x3, y, norepl);
        p.fit_textline("selected glyph available in the font", x4, y, inp);
        
        /* Character reference in HTML style with entity name */
        p.fit_textline("&euro;", x, y-=yoff, inp);
        p.fit_textline("&euro;", x2, y, repl);
        p.fit_textline("&euro;", x3, y, norepl);
        p.fit_textline("selected glyph available in the font", x4, y, inp);
        
        /* Character reference using a glyph name provided by the font or the
         * Adobe Glyph List (AGL)
         */
        p.fit_textline("&.Euro;", x, y-=yoff, inp);
        p.fit_textline("&.Euro;", x2, y, repl);
        p.fit_textline("&.Euro;", x3, y, norepl);
        p.fit_textline("selected glyph available in the font", x4, y, inp);
        
        /* Character reference using a glyph name provided by the Adobe Glyph
         * list (AGL)
         */
        p.fit_textline("&.uni20AC;", x, y-=yoff, inp);
        p.fit_textline("&.uni20AC;", x2, y, repl); 
        p.fit_textline("&.uni20AC;", x3, y, norepl);
        p.fit_textline("selected glyph available in the font", x4, y, inp);
        

        /* ---------------------------------------------------------------------
         * Use various notations to output the ligature "ffi" which is available
         * in the font
         * --------------------------------------------------------------------- 
         */
        
        /* Java Unicode notation, 
         * The first string "\\uFB03" is a descriptive text and results in an 
         * output of "\uFB03" since the two slashes are resolved by the Java
         * compiler to one slash. 
         */
        p.fit_textline("\\uFB03", x, y-=yoff, inp);
        p.fit_textline("\uFB03", x2, y, repl);
        p.fit_textline("\uFB03", x3, y, norepl);
        p.fit_textline("ffi ligature available in the font", x4, y, inp);
        
        /* Character reference using a glyph name provided by the font or the
         * Adobe Glyph List (AGL)
         */
        p.fit_textline("&.ffi;", x, y-=yoff, inp);
        p.fit_textline("&.ffi;", x2, y, repl);
        p.fit_textline("&.ffi;", x3, y, norepl);
        p.fit_textline("ffi ligature available in the font", x4, y, inp);
               
        
        /* ---------------------------------------------------------------------
         * Output the glyph for the ligature "st" which is not available in the
         * font. It will be replaced by the two glyphs "s" and "t".
         * --------------------------------------------------------------------- 
         */
        
        /* Java Unicode notation, 
         * The first string "\\uFB06" is a descriptive text and results in an 
         * output of "\uFB06" since the two slashes are resolved by the Java
         * compiler to one slash. 
         */
        p.fit_textline("\\uFB06", x, y-=yoff, inp);
        p.fit_textline("\uFB06", x2, y, repl);
        p.fit_textline("\uFB06", x3, y, norepl);
        p.fit_textline("unavailable st ligature replaced with s and t glyphs",
            x4, y, inp);
        
        
        /* --------------------------------------------------------------------
         * Output the glyph for an alternative g which is available in the font
         * --------------------------------------------------------------------
         */
        p.fit_textline("&.g.alt;", x, y-=yoff, inp);      
        p.fit_textline("&.g.alt;", x2, y, repl); 
        p.fit_textline("&.g.alt;", x3, y, norepl);
        p.fit_textline("g.alt variant glyph available in the font", x4, y, inp);
        
        
        /* -------------------------------------------------------------------
         * Output the Ohm glyph which is not available in the font. It will be
         * replaced by the Omega character.
         * -------------------------------------------------------------------
         */
        p.fit_textline("&.Ohm;", x, y-=yoff, inp);
        p.fit_textline("&.Ohm;", x2, y, repl);
        p.fit_textline("&.Ohm;", x3, y, norepl);
        p.fit_textline("unavailable Ohm replaced by Omega glyph", x4, y, inp);
        
        /* Finish page */
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
