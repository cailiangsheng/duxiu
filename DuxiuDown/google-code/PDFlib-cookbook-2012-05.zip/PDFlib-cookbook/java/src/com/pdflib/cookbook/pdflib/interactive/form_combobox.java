/* $Id: form_combobox.java,v 1.3 2007/10/30 16:16:32 katja Exp $
 * Form combobox:
 * Create a form field of type "combobox" for choosing an item from a list or
 * changing an existing item.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.interactive;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class form_combobox
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary */
    String searchpath = "../input";
    String outfile = "form_combobox.pdf";
    String title = "Form Combobox";
    
    pdflib p = null;

    String optlist;
    int font;
    double width=100, height=18, llx = 100, lly = 600;
  
    try {
        p = new pdflib();

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        p.set_parameter("SearchPath", searchpath);

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");

        font = p.load_font("Helvetica", "winansi", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Start page */
        p.begin_page_ext(0, 0, " width=a4.width height=a4.height");
        
        /* Output a combobox title */
        p.setfont(font, 14);
        p.fit_textline("Choose a size from the list or enter an individual " +
            "value:", llx, lly, "");
        lly-=30;
        
        /* Create a form fields of type "combobox".
         * Provide the box with a light gray background
         * (backgroundcolor={gray 0.9}) and a gray border
         * (bordercolor={gray 0.7}).
         * Set the values for the combobox items (itemnamelist={0 1 2 3 4}).
         * Set the labels for the combobox items (itemtextlist={...}).
         * Set the focus on the last item (currentvalue=4).
         * Allow the user to change an item (editable=true)
         */
        optlist = "font=" + font + " fontsize=14 backgroundcolor={gray 0.9} " +
            "bordercolor={gray 0.7} itemnamelist={0 1 2 3 4} currentvalue=4 " +
            "itemtextlist={S M L XL XXL} editable=true";
        
        /* Create the field with a height similar to the height of one list
         * item
         */ 
        p.create_field(llx, lly, llx + width, lly + height, "size", "combobox",
            optlist);
        
        p.end_page_ext("");
        
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
