/* $Id: image_rounded_corners.java,v 1.6 2012/03/21 14:13:02 rp Exp $
 * Image with rounded corners:
 * Place an image with rounded corners
 *
 * Get the dimensions of an image and create a clipping path as a rectangle of
 * 0.5 of the width and height of the image and with rounded corners. Fit the
 * image into a box with the position and size of the clipping path.
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 8
 * Required data: image file
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class image_rounded_corners
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "image_rounded_corners.pdf";
    String title = "Image with Rounded Corners";

    pdflib p = null;
    String imagefile = "nesrin.jpg";
    int image;
    double width, height;   // width and height of the image
    int radius=50;          // radius of the circle describing a rounded corner
    int x=20, y=20;         // lower left position of the image

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.6 $");

        /* Load image */
        image = p.load_image("auto", imagefile, "");
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Get the width and height of the image */
        width = p.info_image(image, "imagewidth", "");
        height = p.info_image(image, "imageheight", "");

        /* Start a page with the image dimensions */
        p.begin_page_ext(width, height, "");

        /* Save the current graphics state including the clipping path */
        p.save();

        /* Define a path as a rectangle of 0.5 of the original width and height
         * of the image and with rounded corners
         */
        width *= 0.5;
        height *= 0.5;

        p.moveto(x + radius, y);
        p.lineto(x + width - radius, y);
        p.arc(x + width - radius, y + radius, radius, 270, 360);
        p.lineto(x + width, y + height - radius );
        p.arc(x + width - radius, y + height - radius, radius, 0, 90);
        p.lineto(x + radius, y + height);
        p.arc(x + radius, y + height - radius, radius, 90, 180);
        p.lineto(x , y + radius);
        p.arc(x + radius, y + radius, radius, 180, 270);

        /* Set clipping path to defined path */
        p.clip();

        /* Load image */
        image = p.load_image("auto", imagefile, "");

        /* Fit the image into a box with the size and start point (x,y) of the
         * clipping path. The image is placed in the center of the box using a
         * fit method of "meet" which will scale the image proportionally until
         * it completely covers the box */
        p.fit_image(image, x, y, "boxsize {" + width + " " + height +
            "} position center fitmethod=meet");

        /* Close image and restore original clipping (no clipping) */
        p.close_image(image);
        p.restore();

        p.end_page_ext("");
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
