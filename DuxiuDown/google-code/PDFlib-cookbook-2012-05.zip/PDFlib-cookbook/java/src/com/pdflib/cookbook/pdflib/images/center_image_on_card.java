/* $Id: center_image_on_card.java,v 1.3 2007/10/30 16:16:34 katja Exp $
 * Center image on card:
 * Place an image on an imported PDF card
 *
 * The image will be placed in the center on the imported PDF page and scaled
 * to 80% of the page size. The height of the image will be scaled accordingly
 * so that the picture will stay in ratio.
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document, image file
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class center_image_on_card
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "center_image_on_card.pdf";
    String title = "Center Image on Card";

    pdflib p = null;
    String imagefile = "nesrin.jpg";
    String cardfile = "card.pdf";
    int image, card, cardpage;
    double cardwidth, cardheight;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");

        /* Load the image */
        image = p.load_image("auto", imagefile, "");

        if (image == -1)
        throw new Exception("Error: " + p.get_errmsg());

        /* Load the card file */
        card = p.open_pdi_document(cardfile, "");
        if (card == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Load the first page of the card file */
        cardpage = p.open_pdi_page(card, 1, "");
        if (cardpage == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Query the width and height of the first page of the card */
        cardwidth = p.pcos_get_number(card, "pages[0]/width");
        cardheight = p.pcos_get_number(card, "pages[0]/height");

        /* Create a page with the width and height of the card */
        p.begin_page_ext(0, 0, "width=" + cardwidth + " height=" + cardheight);

        /* Place the card page */
        p.fit_pdi_page(cardpage, 0, 0, "");

        /* Place the image in the center of a box which covers 80% of the card
         * size and starts from 10 percent of the card width and height. Fit
         * the image proportionally into the box so that it will cover 80% of
         * the card size as well.
         */
        p.fit_image(image, cardwidth * 0.1, cardheight * 0.1,
                "boxsize={" + cardwidth * 0.8 + " " + cardheight * 0.8 +
                "} position=center fitmethod=meet");

        p.end_page_ext("");
        p.close_image(image);
        p.close_pdi_page(cardpage);
        p.close_pdi_document(card);
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
