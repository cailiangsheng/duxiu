/* $Id: stamp_pages.java,v 1.16 2011/08/01 14:44:32 stm Exp $
 * Stamp PDF pages:
 * Import all pages from an existing PDF document and place a stamp somewhere
 * on the page
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document
 */
package com.pdflib.cookbook.pdflib.pdf_import;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class stamp_pages
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "stamp_pages.pdf";
    String title = "Stamp Pages";

    pdflib p = null;
    String pdffile = "PDFlib-real-world.pdf";
    int indoc, pageno, endpage, page, font;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.16 $");

        /* Open the input PDF */
        indoc = p.open_pdi_document(pdffile, "");
        if (indoc == -1)
            throw new Exception("Error: " + p.get_errmsg());

        endpage = (int) p.pcos_get_number(indoc, "length:pages");

        /* Loop over all pages of the input document */
        for (pageno = 1; pageno <= endpage; pageno++)
        {
            page = p.open_pdi_page(indoc, pageno, "");

            if (page == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Dummy page size; will be adjusted later */
            p.begin_page_ext(10, 10, "");

            /* Place the imported page on the output page, and
             * adjust the page size
             */
            p.fit_pdi_page(page, 0, 0, "adjustpage");

            /* For PDFlib Lite: change "unicode" to "winansi" */
            font = p.load_font("Helvetica-Bold", "unicode", "");

            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Fit the text line like a stamp with green outlines in the
             * specified box. The stamp will be placed diagonally from the 
             * upper left to the lower right.
             */
            p.fit_textline("PRELIMINARY", 50, 50, "font=" + font +
	       " fontsize=1 textrendering=1 boxsize={500 700} stamp=ul2lr" +
	       " strokecolor={rgb 1 0 0} strokewidth=2");

            p.close_pdi_page(page);

            p.end_page_ext("");
        }

        p.end_document("");

        } catch (PDFlibException e){
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
