/* $Id: add_opi_info.java,v 1.4 2009/07/13 11:32:31 rjs Exp $
 * Add OPI information:
 * Attach OPI information to an image
 * 
 * Use the "OPI-1.3" or "OPI-2.0" options of load_image() to attach OPI
 * information according to OPI 1.3 or OPI 2.0 to an image, respectively.
 * 
 * From the PDF Reference:
 * The Open Prepress Interface (OPI) is a mechanism, originally developed by
 * Aldus Corporation, for creating low-resolution placeholders, or proxies, for
 * such high-resolution images. The proxy typically consists of a downsampled
 * version of the full-resolution image, to be used for screen display and
 * proofing. Before the document is printed, it passes through a filter known as
 * an OPI server, which replaces the proxies with the original full-resolution
 * images.
 * 
 * OPI information in PostScript files is generally referred to as 
 * "OPI comments". Note that replacing images with OPI always requires suitable
 * OPI processing software. PDF display with Acrobat will not be affected by
 * OPI.
 *
 * For more details refer to the OPI 2.0 specification, which is available at
 * http://partners.adobe.com/public/developer/en/ps/5660_OPI_2_0.pdf.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: image file
 */
package com.pdflib.cookbook.pdflib.images;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class add_opi_info
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "add_opi_info.pdf";
    String title = "Add OPI Information";

    pdflib p = null;
    String imagefile = "nesrin.jpg";
    int font, image;
    int x = 20, y = 500;
    int llx = 20, urx = 430, lly = 20, ury = 460;
    int tf = -1;
    
    /* The "normalizefilename" option is required for some OPI servers. If it is
     * false (default), the supplied image file name will be used without any
     * modification; if it is true the image file name will be normalized as
     * mandated by the PDF reference.
     * 
     * The examples below use only the required OPI options. For more OPI 1.3
     * and 2.0 options refer to the PDFlib API reference. The set of useful 
     * options depends on the type of OPI server used.
     */
    String optlist13 =
        "OPI-1.3={normalizefilename                                  " +
                 "ALDImageFilename={nesrin_hires.jpg}                " +
                 "ALDImageDimensions={745 493}                       " +
                 "ALDImageCropRect={10 10 550 390}                   " +
                 "ALDImagePosition={10 10  10 540  390 540  390 10}  " +
                 "ALDImageColor={0 0 0 0.5 CustomGray}               " +
                 "ALDImageColorType=Separation                      }";
    
    String optlist20 =
        "OPI-2.0={normalizefilename                                  " +
                 "ImageFilename={nesrin_hires.jpg}                   " +
                 "ImageCropRect={10 10 550 390}                      " +
                 "ImageDimensions={745 493}                         }";
    
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.4 $");
        
        /* Load the font */
        font = p.load_font("Courier", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
     
        /* -------------------------------------------------------------
         * Place the image in its original size with OPI 1.3 information 
         * attached
         * -------------------------------------------------------------
         */
        /* Load the image with the option list for OPI 1.3 information */
        image = p.load_image("auto", imagefile, optlist13);
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Start page 1 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
  
        p.fit_image(image, x, y, "scale=0.5");
        
        tf = p.add_textflow(tf, "", "font=" + font + " fontsize=12");
        
        tf = p.add_textflow(tf,
            "Option list for load_image() for OPI 1.3 information:\n\n", "");
        
        tf = p.add_textflow(tf, optlist13, "");
        
        p.fit_textflow(tf, llx, lly, urx, ury, "");
        
        p.end_page_ext("");
        
        p.close_image(image);  
        
        tf = -1;
                
        
        /* -------------------------------------------------------------
         * Place the image in its original size with OPI 2.0 information 
         * attached
         * -------------------------------------------------------------
         */
        /* Load the image with the option list for OPI 2.0 information */
        image = p.load_image("auto", imagefile, optlist20);
        if (image == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Start page 2 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
                      
        p.fit_image(image, x, y, "scale=0.5");
        
        tf = p.add_textflow(tf, "", "font=" + font + " fontsize=12");
        
        tf = p.add_textflow(tf,
            "Option list for load_image() for OPI 2.0 information:\n\n", "");
        
        tf = p.add_textflow(tf, optlist20, "");
        
        p.fit_textflow(tf, llx, lly, urx, ury, "");
        
        p.end_page_ext("");
                
        p.close_image(image);

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.toString());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
