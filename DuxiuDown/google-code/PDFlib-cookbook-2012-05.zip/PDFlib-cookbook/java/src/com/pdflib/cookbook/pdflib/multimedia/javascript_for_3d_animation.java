package com.pdflib.cookbook.pdflib.multimedia;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

/**
 * JavaScript for 3D animation: Load a PRC 3D model and animate it with 
 * JavaScript.
 *
 * Define a 3D view and load some 3D data with the view defined. JavaScript 
 * code animates the model by using a TimeEventHandler object.
 *
 * Acrobat 9 or above is required for viewing PDF documents containing a
 * PRC 3D model.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 8.0.3
 * Required data: PRC data file
 * 
 * @version $Id: javascript_for_3d_animation.java,v 1.1 2011/08/02 13:01:15 stm Exp $
 */
public class javascript_for_3d_animation {
    /**
     * JavaScript code for rotating the model around the z axis.
     */
    final static String JS_ANIMATION =
        "scene.lightScheme = scene.LIGHT_MODE_DAY;\n"
        + "var myTimeHandler = new TimeEventHandler();\n"
        + "myTimeHandler.onEvent = function(event)\n"
        + "{\n"
            + "var mesh = scene.meshes.getByIndex(0);\n"
            + "mesh.transform.rotateAboutZInPlace(0.02);\n"
        + "}\n"
        + "runtime.addEventHandler(myTimeHandler);\n";
    
    public static void main(String argv[]) {
        /* This is where the data files are. Adjust if necessary. */
        String searchpath = "../input";
        String outfile = "javascript_for_3d_animation.pdf";
        String title = "JavaScript for 3D animation";

        pdflib p = null;

        /* Required minimum PDFlib version */
        final double requiredversion = 803;
        final String requiredvstr = "8.0.3";

        String optlist;
        int font, view;

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            /* Check whether the required minimum PDFlib version is available */
            double major = p.get_value("major", 0);
            double minor = p.get_value("minor", 0);
            double revision = p.get_value("revision", 0);

            if (major * 100 + minor * 10 + revision < requiredversion)
                throw new Exception("Error: PDFlib " + requiredvstr
                    + " or above is required");

            /* Start the document */
            if (p.begin_document(outfile, "compatibility=1.7ext3") == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.1 $");

            font = p.load_font("Helvetica", "winansi", "");
            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /*
             * Create a 3D view that shows the whole model.
             */
            optlist = "type=PRC background={fillcolor=mediumslateblue} "
                + "camera2world={-1 0 0 "
                		+ "0 1 0.00157 "
    				+ "0 0.00157 -1 "
    				+ "0 -2.47457 332.5437}";
            if ((view = p.create_3dview("Default", optlist)) == -1)
                throw new Exception("Error: " + p.get_errmsg());

            make_3d_page(p, font, view, "Animate model with JavaScript",
                                        JS_ANIMATION);

            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }

    /**
     * Page width in points (landscape).
     */
    final static int WIDTH = 842;
    
    /**
     * Page height in points (landscape).
     */
    final static int HEIGHT = 595;
    
    /**
     * Margin around textflow and 3D annotation.
     */
    final static int MARGIN = 50;
    
    /**
     * Display the 3D annotation and the JavaScript to animate the model
     * side-by-side on a landscape PDF page.
     * 
     * @param p
     *            PDFlib object
     * @param data
     *            3D data
     * @param view
     *            3D default view
     * @param font
     *            font for displaying the JavaScript code
     * @param title
     *            title to display above the JavaScript code
     * @param javascript
     *            JavaScript code
     * 
     * @throws PDFlibException
     * @throws Exception
     */
    private static void make_3d_page(pdflib p, int font, int view,
            String title, String javascript) throws PDFlibException, Exception {
        String optlist;
        int tf = -1;
        final int element_width = (WIDTH - 3 * MARGIN) / 2;
        final int element_height = HEIGHT - 2 * MARGIN;
        final int tf_xpos = MARGIN;
        final int tf_ypos = MARGIN;
        final int tf_width = element_width;
        final int _3d_xpos = 2 * MARGIN + element_width;
        final int _3d_ypos = MARGIN;
        final int _3d_width = element_width;
        
        optlist = "font=" + font + " fontsize=14 underline=true";
        tf = p.add_textflow(tf, title + "\n\n", optlist);
        optlist = "font=" + font + " fontsize=12 underline=false";
        tf = p.add_textflow(tf, "JavaScript code:\n\n", optlist);
        tf = p.add_textflow(tf, javascript, "");
        
        p.begin_page_ext(WIDTH, HEIGHT, "");

        /* Create a bookmark for jumping to this page */
        p.create_bookmark(title, "");
        
        p.fit_textflow(tf, tf_xpos, tf_ypos,
                tf_xpos + tf_width, tf_ypos + element_height,
                "fitmethod=auto");
        
        /*
         * Load 3D data with the view defined above and with the JavaScript
         * for animation.
         */
        int data = p.load_3ddata("riemann.prc", "type=PRC views={" + view + "} "
            + "script={" + javascript + "}");
        if (data == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /*
         * Create an annotation containing the loaded 3D data with the
         * defined 3D view as the initial view
         */
        optlist = "contents=PRC 3Ddata= " + data + " "
            + "3Dactivate={enable=open} 3Dinitialview=" + view;
        p.create_annotation(_3d_xpos, _3d_ypos, 
            _3d_xpos + _3d_width, _3d_ypos + element_height, "3D",
            optlist);

        p.end_page_ext("");
    }
}
