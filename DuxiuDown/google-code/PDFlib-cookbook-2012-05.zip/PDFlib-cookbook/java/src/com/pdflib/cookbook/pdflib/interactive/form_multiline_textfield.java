/* $Id: form_multiline_textfield.java,v 1.2 2007/10/30 16:16:32 katja Exp $
 * Form multiline text field:
 * Create a form field of type "textfield" for entering multiline text
 * 
 * Create the "comment" text field for entering multiline text which is not
 * allowed to scroll out of the window. Define the following field properties: 
 * default text, border and fill color, tooltip, tab order position.
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.interactive;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class form_multiline_textfield
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary */
    String searchpath = "../input";
    String outfile = "form_multiline_textfield.pdf";
    String title = "Form Multiline Textfield";
    
    pdflib p = null;

    String optlist;
    int font;
    double width=200, height=80;
    double llx = 30, lly = 500;

    try {
        p = new pdflib();

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        p.set_parameter("SearchPath", searchpath);

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.2 $");

        font = p.load_font("Helvetica", "winansi", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Start page */
        p.begin_page_ext(0, 0, " width=a4.width height=a4.height");
        
        /* Create a multiline text field called "comment" (multiline=true).
         * Don't allow the text to be scrolled out of the field
         * (scrollable=false).
         * Define a tooltip (tooltip={Enter a comment}).
         */
        optlist = "backgroundcolor={rgb 0.95 0.95 1}  bordercolor={gray 0} " +
            "currentvalue={Enter a multiline comment} multiline=true " +
            "scrollable=false tooltip={Enter a comment} font =" + font +
            " fontsize=14";
        
        p.create_field(llx, lly, llx + width, lly + height, "comment",
            "textfield", optlist);
    
        p.setfont(font, 12);
        p.fit_textline("Multiline text field; a tooltip is provided.",
            llx, lly-=30, "");
        p.fit_textline("Text is not allowed to scroll out of the window.",
            llx, lly-=20, "");
        
        p.end_page_ext("");
        
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
