/* $Id: retain_font.java,v 1.3 2010/01/22 16:29:55 stm Exp $
 * 
 * Retain fonts:
 * Demonstrate performance benefits of keeping a font open across multiple 
 * documents.
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 8
 * Required data: Fallback font
 */
package com.pdflib.cookbook.pdflib.fonts;

import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class retain_font {
    
    /**
     * Name of the font to load.
     */
    private static final String FONTNAME = "fallback";

    /**
     * Number of documents to generate.
     */
    final static int N_DOCS = 100;
    
    /**
     * This is where the data files are. Adjust as necessary.
     */
    final static String SEARCH_PATH = "../input";
    
    /**
     * Page width
     */
    final static double WIDTH = 595;
    
    /**
     * Page height
     */
    final static double HEIGHT = 842;
    
    /**
     * Method that creates N_DOCS documents in memory.
     * 
     * @param keepfont
     *            if true, retain font across all generated documents, otherwise
     *            load it again for each document
     */
    static void make_test_docs(boolean keepfont) {
        pdflib p = null;

        try {
            int font = -1;
            
            p = new pdflib();

            p.set_parameter("SearchPath", SEARCH_PATH);

            /*
             * Load a font
             */
            if (keepfont) {
                /*
                 * keepfont=true is default here, so it does not need to be
                 * specified explicitly.
                 */
                font = p.load_font(FONTNAME, "unicode", "keepfont=true");
                if (font == -1)
                    throw new Exception("Error: " + p.get_apiname() + ": "
                            + p.get_errmsg());
            }

            for (int i = 0; i < N_DOCS; i += 1) {
                /*
                 * Create a simple document that makes use of the font. The
                 * document is generated in memory and immediately discarded.
                 */
                if (p.begin_document("", "") == -1)
                    throw new Exception("Error: " + p.get_apiname() + ": "
                            + p.get_errmsg());

                p.set_info("Creator", "PDFlib Cookbook");
                p.set_info("Title", "Dummy test document");

                p.begin_page_ext(WIDTH, HEIGHT, "");

                if (!keepfont) {
                    /*
                     * keepfont=false is default here.
                     */
                    font = p.load_font(FONTNAME, "unicode", "keepfont=false");
    
                    if (font == -1)
                        throw new Exception("Error: " + p.get_apiname() + ": "
                                + p.get_errmsg());
                }

                p.setfont(font, 24);

                p.set_text_pos(50, 700);
                p.show("Hello world!");

                p.end_page_ext("");

                p.end_document("");
            }
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                    + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }
    
    public static void main(String argv[]) {
        final String outfile = "retain_font.pdf";
        final String title = "Retain Fonts";
        final NumberFormat form = NumberFormat.getInstance(Locale.US);
        form.setMaximumFractionDigits(2);
        form.setMinimumFractionDigits(0);
        
        pdflib p = null;
        int font;

        /*
         * Time creation of test documents with and without retaining of font.
         */
        long start_date1 = new Date().getTime();
        make_test_docs(false);
        String time_diff1 = 
            form.format((new Date().getTime() - start_date1) / 1000.0);
        
        long start_date2 = new Date().getTime();
        make_test_docs(true);
        String time_diff2 = 
            form.format((new Date().getTime() - start_date2) / 1000.0);
        
        try {
            p = new pdflib();

            p.set_parameter("SearchPath", SEARCH_PATH);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            if (p.begin_document(outfile, "") == -1)
                throw new Exception("Error: " + p.get_apiname() + ": "
                        + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.3 $");

            p.begin_page_ext(595, 842, "");

            font = p.load_font("Helvetica", "unicode", "");

            if (font == -1)
                throw new Exception("Error: " + p.get_apiname() + ": "
                        + p.get_errmsg());

            p.setfont(font, 18);

            p.set_text_pos(50, 700);
            p.show("Performance benefit of retaining a font across documents:");
            
            p.setfont(font, 16);
            p.continue_text("");
            p.continue_text("Time spent for creating " + N_DOCS 
                        + " documents without retaining font:");
            p.continue_text(time_diff1 + " seconds");
            
            p.continue_text("");
            p.continue_text("Time spent for creating " + N_DOCS 
                        + " documents while retaining font:");
            p.continue_text(time_diff2 + " seconds");
            
            p.continue_text("");
            p.continue_text("Note: Actual results will vary depending on various factors,");
            p.continue_text("including font, complexity of the document and platform.");
            
            p.end_page_ext("");

            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                    + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
