/* $Id: import_pdfx.java,v 1.3 2011/08/01 14:44:31 stm Exp $
 * Import PDF/X:
 * Import an existing PDF/X-3 document and output it as PDF/X-3
 * 
 * Only the pages from the imported documents are merged; interactive elements
 * will be ignored.
 *
 * Required software: PDFlib+PDI/PPS 7
 * Required data: PDF document
 */
package com.pdflib.cookbook.pdflib.pdfx;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class import_pdfx
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "import_pdfx.pdf";
    String title = "Import PDF/X";

    pdflib p = null;
    String pdffile = "PLOP-datasheet-PDFX-3-2002.pdf";
    int indoc, pageno, endpage, page;
    double ret;
    String res;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");
        
        /* Set the desired PDF/X conformance level */
        if (p.begin_document(outfile, "pdfx=PDF/X-3:2002") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.3 $");
        
        /* Open the input PDF */
        indoc = p.open_pdi_document(pdffile, "");
        if (indoc == -1)
            throw new Exception("Error: " + p.get_errmsg());

        endpage = (int) p.pcos_get_number(indoc, "length:pages");
        
        /* Since the input document contains its own output intent retrieve
         * the output intent from the input document and copy it to the output
         * document
         */
        res = p.pcos_get_string(indoc, "type:/Root/OutputIntents");
        if (res.equals("array")) {
            ret = p.process_pdi(indoc, -1, "action=copyoutputintent");
            if (ret == -1)
                throw new Exception("Error: " + p.get_errmsg());
        }
        else {
            throw new Exception("Error: " +
                "Invalid PDF/X (output intent is not an array)"); 
        }

        /* Loop over all pages of the input document */
        for (pageno = 1; pageno <= endpage; pageno++)
        {
            page = p.open_pdi_page(indoc, pageno, "");

            if (page == -1)
                throw new Exception("Error: " + p.get_errmsg());

            /* Dummy page size; will be adjusted later */
            p.begin_page_ext(10, 10, "");

            /* Place the imported page without performing any changes on the
             * output page
             */
            p.fit_pdi_page(page, 0, 0, "adjustpage");
            
            p.close_pdi_page(page);
            p.end_page_ext("");
        }

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
