/* $Id: block_below_contents.java,v 1.6 2007/12/06 12:08:13 katja Exp $
 * Block below contents:
 * Fill PDFlib blocks so that they are placed below the imported page
 * 
 * Fill PDFlib blocks such that not the block contents are placed on top of the
 * original imported page, but the other way round. 
 * Place the PDF page using PDF_fit_pdi_page(), but supply the "blind" option
 * to suppress the actual page contents. Fill the block(s) as desired. Place the
 * PDF page again, this time without the "blind" option.
 * 
 * Required software: PPS 7
 * Required data: PDF document containing blocks
 */
package com.pdflib.cookbook.pdflib.blocks;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class block_below_contents
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "block_below_contents.pdf";
    String title = "Block below Contents";

    pdflib p = null;
    double width, height;
    String infile = "announcement_blocks.pdf";
    int tf = -1, inpage, indoc;
    String optlist;
    
    /* Name of the block contained on the imported page */
    final String blockname = "offer"; 
    
    final String offer = 
        "SPECIAL\nSEASON\nOFFER\nby the\nPAPERFIELD\nPLANE CENTER";
 
    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.6 $");

        /* Open a PDF containing blocks */
        indoc = p.open_pdi_document(infile, "");
        if (indoc == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Open the first page */
        inpage = p.open_pdi_page(indoc, 1, "");
        if (inpage == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Get the width and height of the imported page */
        width = p.pcos_get_number(indoc, "pages[0]/width");
        height = p.pcos_get_number(indoc, "pages[0]/height");
        
        /* Start the output page with the size given by the imported page */ 
        p.begin_page_ext(width, height, "");

        /* Place the imported page on the output page but supply the "blind"
         * option to suppress the actual page contents
         */
        p.fit_pdi_page(inpage, 0, 0, "blind");
        
        /* Fill one block with the Textflow */ 
        String text = offer;
              
        /* Option list for text blocks; the font and encoding should be 
         * defined and the Textflow handle supplied. "alignment=center" is used
         * to center the text horizontally. Other options have
         * already been set in the properties of the blocks contained in
         * the input document, such as:
         * "fitmethod=clip" to clip the text when it doesn't fit completely
         * into the block while avoiding any text shrinking.
         * "margin=4" to set some space between the text and the borders of
         * the block rectangle.
         * "fontsize=60" as a font size of 60.
         * "fillcolor={gray 0.9}" to output the text in a light gray.
        */
        optlist = "fontname=Helvetica-Bold encoding=unicode alignment=center " +
            "textflowhandle=" + tf;
           
        tf = p.fill_textblock(inpage, blockname, text, optlist);
                
        if (tf == -1)
            System.err.println("Warning: " + p.get_errmsg());
                
        p.delete_textflow(tf);
        
        /* Place the imported page again but this time without the "blind"
         * option supplied
         */
        p.fit_pdi_page(inpage, 0, 0, "");

        p.end_page_ext("");
           
        p.close_pdi_page(inpage);

        p.end_document("");
        p.close_pdi_document(indoc);

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
