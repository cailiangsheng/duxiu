/* $Id: page_x_of_y.java,v 1.6 2007/08/30 18:30:35 katja Exp $
 * Create page X of Y:
 * Create a running footer "Page x of y" on each page of the document
 *
 * On each page a running header or footer "Page x of y" is required where x is
 * the current page number and y is the total number of pages in the document.
 * Since y is only known after creating all pages, the number y must be added
 * to each page after creating the bulk of the document.
 *
 * This topic demonstrates the use of suspend/resume_page().
 *
 * Required software: PDFlib Lite/PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.pagination;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class page_x_of_y
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary. */
    String searchpath = "../input";
    String outfile = "page_x_of_y.pdf";
    String title = "Create Page X of Y";

    pdflib p = null;
    int font, x = 500, y = 20, pagecount = 0;

    try {
        p = new pdflib();

        p.set_parameter("SearchPath", searchpath);

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.6 $");

        /* For PDFlib Lite: change "unicode" to "winansi" */
        font = p.load_font("Helvetica", "unicode", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());

        /* Create some pages while counting the total number of pages.
         * Suspend the creation of each page to be able to add the total number
         * of pages later. Resume the page creation to add the total number of
         * pages in a footer like "Page X of Y".
         *
         * Create page 1
         */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");

        pagecount++;
        p.setcolor("fill", "rgb", 0, 0.4, 0.4, 0);
        p.setfont(font, 12);
        p.show_xy("Page 1", x, y);

        /* Suspend page 1 to resume it later */
        p.suspend_page("");

        /* Create page 2 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        pagecount++;
        p.setcolor("fill", "rgb", 0, 0.4, 0.4, 0);
        p.setfont(font, 12);
        p.show_xy("Page 2", x, y);

        /* Suspend page 2 to resume it later */
        p.suspend_page("");

        /* Create page 3 */
        p.begin_page_ext(0, 0, "width=a4.width height=a4.height");
        pagecount++;
        p.setcolor("fill", "rgb", 0, 0.4, 0.4, 0);
        p.setfont(font, 12);
        p.show_xy("Page 3", x, y);

        /* Suspend page 3 to resume it later */
        p.suspend_page("");

        /* Revisit page 1 */
        p.resume_page("pagenumber 1");

        /* Add the total number of pages */
        p.show(" of " + pagecount);
        p.end_page_ext("");

        /* Revisit page 2 */
        p.resume_page("pagenumber 2");

        /* Add the total number of pages */
        p.show(" of " + pagecount);
        p.end_page_ext("");

        /* Revisit page 3 */
        p.resume_page("pagenumber 3");

        /* Add the total number of pages */
        p.show(" of " + pagecount);
        p.end_page_ext("");

        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
