/* $Id: form_textfield_input_check.java,v 1.4 2012/03/29 11:24:30 rp Exp $
 * Form text field input check:
 * Check if the date entered in a form field of type "textfield" has been
 * formatted correctly.
 * 
 * Create a text field for displaying a date and check if the input has been
 * correctly formatted as "mmm dd yyyy, e.g. "Oct 12 2007". 
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.interactive;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class form_textfield_input_check
{
    public static void main (String argv[])
    {
    /* This is where the data files are. Adjust as necessary */
    String searchpath = "../input";
    String outfile = "form_textfield_input_check.pdf";
    String title = "Form Text Field Input Check";
    
    pdflib p = null;

    String optlist;
    int font, monospaced_font;
    double fontsize, ascender, descender;
    double width=160, height=30, llx = 10, lly = 700;

    try {
        p = new pdflib();

        /* This means we must check return values of load_font() etc. */
        p.set_parameter("errorpolicy", "return");

        p.set_parameter("SearchPath", searchpath);

        if (p.begin_document(outfile, "") == -1)
            throw new Exception("Error: " + p.get_errmsg());

        p.set_info("Creator", "PDFlib Cookbook");
        p.set_info("Title", title + " $Revision: 1.4 $");

        font = p.load_font("Helvetica", "winansi", "");
        if (font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        monospaced_font = p.load_font("Courier", "winansi", "");
        if (monospaced_font == -1)
            throw new Exception("Error: " + p.get_errmsg());
        
        /* Start page */
        p.begin_page_ext(0, 0, " width=a4.width height=a4.height");
        
        /* Adjust the font size to match the field height. Then, descrease the
         * font size by e.g. 20% to leave some empty space from the field
         * borders.
         */
        ascender = p.info_font(monospaced_font, "ascender", "fontsize=" +
            height);
        descender = p.info_font(monospaced_font, "descender", "fontsize=" +
            height);
        fontsize = (ascender - descender) * 0.8;
        
        /* For a correct formatting of the date, define a keystroke and a
         * formatting action for the date to be checked for compliance to the
         * format "mmm dd yyyy". 
         */
        int keystroke_action = p.create_action("JavaScript",
            "script={AFDate_KeystrokeEx('mmm dd yyyy'); }");
 
        /* Create a form field of type "textfield" called "date" with the
         * JavaScript action supplied in the "action" option
         */
        optlist = "backgroundcolor={rgb 0.95 0.95 1} bordercolor={gray 0} " +
            "currentvalue={Sep 12 2007} maxchar=11 comb=true " +
            "scrollable=false tooltip={Enter a date} font=" + monospaced_font + 
            " fontsize=" + fontsize +
            " action={keystroke=" + keystroke_action + "}";
              
        p.create_field(llx, lly, llx + width, lly + height, "date", "textfield",
            optlist);
        lly-=40;
        
        p.setfont(font, 12);
        p.fit_textline("Change the date.", llx, lly, "");
        p.fit_textline("After pressing \"Enter\", the date is checked to be " +
            "correctly formatted as \"mmm dd yyy\".", llx, lly-=20, "");
        
        p.end_page_ext("");
        
        p.end_document("");

        } catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname() +
                ": " + e.get_errmsg() + "\n");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            if (p != null) {
                p.delete();
            }
        }
    }
}
