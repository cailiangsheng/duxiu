/* $Id: text_to_pdfa.java,v 1.2 2009/07/13 11:32:33 rjs Exp $
 * Text to PDF/A:
 * Output text conforming to PDF/A-1b, taking care of color space and font
 * issues
 *
 * Required software: PDFlib/PDFlib+PDI/PPS 7
 * Required data: font file
 */
package com.pdflib.cookbook.pdflib.pdfa;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class text_to_pdfa {
    public static void main(String argv[]) {
        /* This is where the data files are. Adjust as necessary. */
        String searchpath = "../input";
        String outfile = "text_to_pdfa.pdf";
        String title = "Text to PDF/A";

        pdflib p = null;
        int x = 30, y = 800;

        try {
            p = new pdflib();

            p.set_parameter("SearchPath", searchpath);

            /* This means we must check return values of load_font() etc. */
            p.set_parameter("errorpolicy", "return");

            check_pdflib_version(p, 7, 0, 4);

            /* Output all contents conforming to PDF/A-1b */
            if (p.begin_document(outfile, "pdfa=PDF/A-1b:2005") == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.set_info("Creator", "PDFlib Cookbook");
            p.set_info("Title", title + " $Revision: 1.2 $");

            /*
             * Use sRGB as output intent since it allows the color spaces
             * CIELab, ICC-based, Grayscale, and RGB
             */
            p.load_iccprofile("sRGB", "usage=outputintent");

            p.begin_page_ext(595, 842, "");

            /*
             * Load the font "LuciduxSans-Oblique" with embedding, since font
             * embedding is required for PDF/A
             */
            int font = p.load_font("LuciduxSans-Oblique", "unicode",
                    "embedding");
            if (font == -1)
                throw new Exception("Error: " + p.get_errmsg());

            p.setfont(font, 20);

            /*
             * You might want to embed a PDF core font, e.g. "Helvetica". For a
             * PDF core font, the font metrics are already built into PDFlib,
             * but the font outline file has to be explicitly configured with
             * the "FontOutline" ressource category, e.g.
             * 
             * p.set_parameter("FontOutline", "Helvetica=HV______.pfb");
             */

            /*
             * We can use RGB text without any further color related options
             * since we already supplied an output intent profile.
             */
            p.setcolor("fill", "rgb", 0.7, 0.3, 0.3, 0);

            p.fit_textline(
                    "Text with an RGB color conforming to PDF/A-1b:2005", x,
                    y -= 100, "");

            /*
             * Similarly, we can use Grayscale text without any further options
             * since we already supplied an output intent profile.
             */
            p.setcolor("fill", "gray", 0.5, 0, 0, 0);

            p.fit_textline("Text with a Grayscale color conforming to "
                    + "PDF/A-1b:2005", x, y -= 100, "");

            /*
             * For CMYK text we could use an ICC profile explicitly assigned;
             * the code would be as follows:
             * 
             * icc = p.load_iccprofile("ISOcoated.icc", "usage=iccbased");
             * p.set_value("setcolor:iccprofilecmyk", icc);
             * p.setcolor("fill", "iccbasedcmyk", 0.6, 0.6, 0, 0);
             * p.fit_textline(
             *     "Text with a CMYK color conforming to PDF/A-1b:2005",
             *     x, y-=100, "");
             */

            p.end_page_ext("");

            p.end_document("");
        }
        catch (PDFlibException e) {
            System.err.print("PDFlib exception occurred:\n");
            System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
                    + ": " + e.get_errmsg() + "\n");
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            if (p != null) {
                p.delete();
            }
        }
    }

    /**
     * Check whether the required minimum PDFlib version is available
     * 
     * @param p
     *            the pdflib object
     * @param major
     *            PDFlib major version number
     * @param minor
     *            PDFlib minor version number
     * @param revision
     *            PDFlib revision number
     * 
     * @throws PDFlibException
     * @throws Exception
     */
    private static void check_pdflib_version(pdflib p, int major, int minor,
            int revision) throws PDFlibException, Exception {
        final int actualMajor = (int) p.get_value("major", 0);
        final int actualMinor = (int) p.get_value("minor", 0);
        final int actualRevision = (int) p.get_value("revision", 0);

        /* Required minimum PDFlib version */
        final int requiredVersion = major * 100 + minor * 10 + revision;
        final int actualVersion = actualMajor * 100 + actualMinor * 10
                + actualRevision;

        if (actualVersion < requiredVersion) {
            throw new Exception("Error: PDFlib " + major + "." + minor + "."
                    + revision + " or above is required");
        }
    }
}
