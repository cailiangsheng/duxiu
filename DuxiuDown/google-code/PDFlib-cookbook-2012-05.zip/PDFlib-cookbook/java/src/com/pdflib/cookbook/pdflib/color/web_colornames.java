/* $Id: web_colornames.java,v 1.4 2009/10/12 12:14:23 stm Exp $
 * 
 * Web color names:
 * View a list of all cross-browser colors including the color name and 
 * hexadecimal color value as well as the corresponding RGB color values.
 * 
 * Cross-browser color names are a collection of nearly 150 color names which
 * are supported by all major browsers. For more information, see 
 * http://www.w3schools.com/html/html_colors.asp
 * http://www.w3.org/TR/SVG/types.html
 * http://en.wikipedia.org/wiki/Web_colors
 * 
 * Required software: PDFlib/PDFlib+PDI/PPS 8
 *    
 * Required data: none
 */
package com.pdflib.cookbook.pdflib.color;

import java.text.NumberFormat;
import java.util.*;

import com.pdflib.pdflib;
import com.pdflib.PDFlibException;

public class web_colornames {

	public static void main(String argv[]) {
		/* This is where the data files are. Adjust as necessary. */
		String searchpath = "../input";
		String outfile = "web_colornames.pdf";
		String title = "Web Color Names";

		pdflib p = null;
		int row, font, tbl = -1;
		String optlist, cellopts, result;

		double red, green, blue;

		final int margin = 6;
		final int fontsize = 12;

		/*
		 * Height of a table row which is the sum of a font size of 12 and the
		 * upper and lower cell margin of 3 each
		 */
		int rowheight = 18;

		/* Number of rows per table fitbox */
		int nrows = 44;

		/* Width of the first, second, and third column of the table */
		final int c1 = 130, c2 = 100, c3 = 100, c4 = 150;

		/* Coordinates of the lower left corner of the table fitbox */
		final double llx = 35, lly = 30;

		NumberFormat form = NumberFormat.getInstance(Locale.US);

		class color {
			String hex_value;
			String html_name;

			color(String html_name, String hex_value) {
				this.hex_value = hex_value;
				this.html_name = html_name;
			}
		}

		/* HTML color values and names */
		final color colors[] = {
			new color("Maroon", "800000"),
			new color("DarkRed", "8B0000"),
			new color("FireBrick", "B22222"),
			new color("Red", "FF0000"),
			new color("Salmon", "FA8072"),
			new color("Tomato", "FF6347"),
			new color("Coral", "FF7F50"),
			new color("OrangeRed", "FF4500"),
			new color("Chocolate", "D2691E"),
			new color("SandyBrown", "F4A460"),
			new color("DarkOrange", "FF8C00"),
			new color("Orange", "FFA500"),
			new color("DarkGoldenrod", "B8860B"),
			new color("Goldenrod", "DAA520"),
			new color("Gold", "FFD700"),
			new color("Olive", "808000"),
			new color("Yellow", "FFFF00"),
			new color("YellowGreen", "9ACD32"),
			new color("GreenYellow", "ADFF2F"),
			new color("Chartreuse", "7FFF00"),
			new color("LawnGreen", "7CFC00"),
			new color("Green", "008000"),
			new color("Lime", "00FF00"),
			new color("LimeGreen", "32CD32"),
			new color("SpringGreen", "00FF7F"),
			new color("MediumSpringGreen", "00FA9A"),
			new color("Turquoise", "40E0D0"),
			new color("LightSeaGreen", "20B2AA"),
			new color("MediumTurquoise", "48D1CC"),
			new color("Teal", "008080"),
			new color("DarkCyan", "008B8B"),
			new color("Aqua", "00FFFF"),
			new color("Cyan", "00FFFF"),
			new color("DarkTurquoise", "00CED1"),
			new color("DeepSkyBlue", "00BFFF"),
			new color("DodgerBlue", "1E90FF"),
			new color("RoyalBlue", "4169E1"),
			new color("Navy", "000080"),
			new color("DarkBlue", "00008B"),
			new color("MediumBlue", "0000CD"),
			new color("Blue", "0000FF"),
			new color("BlueViolet", "8A2BE2"),
			new color("DarkOrchid", "9932CC"),
			new color("DarkViolet", "9400D3"),
			new color("Purple", "800080"),
			new color("DarkMagenta", "8B008B"),
			new color("Fuchsia", "FF00FF"),
			new color("Magenta", "FF00FF"),
			new color("MediumVioletRed", "C71585"),
			new color("DeepPink", "FF1493"),
			new color("HotPink", "FF69B4"),
			new color("Crimson", "DC143C"),
			new color("Brown", "A52A2A"),
			new color("IndianRed", "CD5C5C"),
			new color("RosyBrown", "BC8F8F"),
			new color("LightCoral", "F08080"),
			new color("Snow", "FFFAFA"),
			new color("MistyRose", "FFE4E1"),
			new color("DarkSalmon", "E9967A"),
			new color("LightSalmon", "FFA07A"),
			new color("Sienna", "A0522D"),
			new color("SeaShell", "FFF5EE"),
			new color("SaddleBrown", "8B4513"),
			new color("Peachpuff", "FFDAB9"),
			new color("Peru", "CD853F"),
			new color("Linen", "FAF0E6"),
			new color("Bisque", "FFE4C4"),
			new color("Burlywood", "DEB887"),
			new color("Tan", "D2B48C"),
			new color("AntiqueWhite", "FAEBD7"),
			new color("NavajoWhite", "FFDEAD"),
			new color("BlanchedAlmond", "FFEBCD"),
			new color("PapayaWhip", "FFEFD5"),
			new color("Moccasin", "FFE4B5"),
			new color("Wheat", "F5DEB3"),
			new color("Oldlace", "FDF5E6"),
			new color("FloralWhite", "FFFAF0"),
			new color("Cornsilk", "FFF8DC"),
			new color("Khaki", "F0E68C"),
			new color("LemonChiffon", "FFFACD"),
			new color("PaleGoldenrod", "EEE8AA"),
			new color("DarkKhaki", "BDB76B"),
			new color("Beige", "F5F5DC"),
			new color("LightGoldenrodYellow", "FAFAD2"),
			new color("LightYellow", "FFFFE0"),
			new color("Ivory", "FFFFF0"),
			new color("OliveDrab", "6B8E23"),
			new color("DarkOliveGreen", "556B2F"),
			new color("DarkSeaGreen", "8FBC8F"),
			new color("DarkGreen", "006400"),
			new color("ForestGreen", "228B22"),
			new color("LightGreen", "90EE90"),
			new color("PaleGreen", "98FB98"),
			new color("Honeydew", "F0FFF0"),
			new color("SeaGreen", "2E8B57"),
			new color("MediumSeaGreen", "3CB371"),
			new color("Mintcream", "F5FFFA"),
			new color("MediumAquamarine", "66CDAA"),
			new color("Aquamarine", "7FFFD4"),
			new color("DarkSlateGray", "2F4F4F"),
			new color("PaleTurquoise", "AFEEEE"),
			new color("LightCyan", "E0FFFF"),
			new color("Azure", "F0FFFF"),
			new color("CadetBlue", "5F9EA0"),
			new color("PowderBlue", "B0E0E6"),
			new color("LightBlue", "ADD8E6"),
			new color("SkyBlue", "87CEEB"),
			new color("LightskyBlue", "87CEFA"),
			new color("SteelBlue", "4682B4"),
			new color("AliceBlue", "F0F8FF"),
			new color("SlateGray", "708090"),
			new color("LightSlateGray", "778899"),
			new color("LightsteelBlue", "B0C4DE"),
			new color("CornflowerBlue", "6495ED"),
			new color("Lavender", "E6E6FA"),
			new color("GhostWhite", "F8F8FF"),
			new color("MidnightBlue", "191970"),
			new color("SlateBlue", "6A5ACD"),
			new color("DarkSlateBlue", "483D8B"),
			new color("MediumSlateBlue", "7B68EE"),
			new color("MediumPurple", "9370DB"),
			new color("Indigo", "4B0082"),
			new color("MediumOrchid", "BA55D3"),
			new color("Plum", "DDA0DD"),
			new color("Violet", "EE82EE"),
			new color("Thistle", "D8BFD8"),
			new color("Orchid", "DA70D6"),
			new color("LavenderBlush", "FFF0F5"),
			new color("PaleVioletRed", "DB7093"),
			new color("Pink", "FFC0CB"),
			new color("LightPink", "FFB6C1"),
			new color("Black", "000000"),
			new color("DimGray", "696969"),
			new color("Gray", "808080"),
			new color("DarkGray", "A9A9A9"),
			new color("Silver", "C0C0C0"),
			new color("LightGrey", "D3D3D3"),
			new color("Gainsboro", "DCDCDC"),
			new color("WhiteSmoke", "F5F5F5"),
			new color("White", "FFFFFF") 
		};

		try {
			p = new pdflib();

			p.set_parameter("SearchPath", searchpath);

			/* This means we must check return values of load_font() etc. */
			p.set_parameter("errorpolicy", "return");

			if (p.begin_document(outfile, "") == -1)
				throw new Exception("Error: " + p.get_errmsg());

			p.set_info("Creator", "PDFlib Cookbook");
			p.set_info("Title", title + " $Revision: 1.4 $");

			/* Load the font */
			font = p.load_font("Courier", "unicode", "");
			if (font == -1)
				throw new Exception("Error: " + p.get_errmsg());

			/* Set some general cell options shared between all cells */
			optlist = "fittextline={font=" + font + " fontsize=" + fontsize
					+ " position={left center}} rowheight=" + rowheight
					+ " margin=" + margin + " ";

			/*
			 * ---------------------------------- 
			 * Add a header containing four cells 
			 * ----------------------------------
			 */

			/* Set the current row */
			row = 1;

			cellopts = optlist + "colwidth=" + c1;

			tbl = p.add_table_cell(tbl, 1, row, "Web Color Name", cellopts);
			if (tbl == -1)
				throw new Exception("Error: " + p.get_errmsg());

			cellopts = optlist + "colwidth=" + c2;

			tbl = p.add_table_cell(tbl, 2, row, "Hex RGB Value", cellopts);
			if (tbl == -1)
				throw new Exception("Error: " + p.get_errmsg());

			cellopts = optlist + "colwidth=" + c3;

			tbl = p.add_table_cell(tbl, 3, row, "   Color", cellopts);
			if (tbl == -1)
				throw new Exception("Error: " + p.get_errmsg());

			cellopts = optlist + "colwidth=" + c4;

			tbl = p.add_table_cell(tbl, 4, row, "  RGB Value in PDFlib",
					cellopts);
			if (tbl == -1)
				throw new Exception("Error: " + p.get_errmsg());

			/*
			 * ------------------------------------------------ 
			 * For each color, add a row containing three cells
			 * ------------------------------------------------
			 */
			for (int i = 0; i < colors.length; i += 1) {
				row = i + 2;
				
				/*
				 * -------------------------------------------------------------
				 * Add the HTML color name in the first column of the current
				 * row
				 * -------------------------------------------------------------
				 */
				cellopts = optlist + "colwidth=" + c1;

				tbl = p.add_table_cell(tbl, 1, row, colors[i].html_name,
						cellopts);
				if (tbl == -1)
					throw new Exception("Error: " + p.get_errmsg());

				/*
				 * --------------------------------------------- 
				 * Add the HTML color value in the second column
				 * ---------------------------------------------
				 */
				cellopts = optlist + "colwidth=" + c2;

				tbl = p.add_table_cell(tbl, 2, row, "#" + colors[i].hex_value,
						cellopts);
				if (tbl == -1)
					throw new Exception("Error: " + p.get_errmsg());

				/*
				 * -------------------------------------------------------------
				 * Retrieve the RGB values used in PDFlib for the
				 * current color. Fetch the value of the i-th color. It consists
				 * of three pairs of hex digits. Each pair indicates the Red,
				 * Green, or Blue component in the range 0-FF which corresponds
				 * to the range 0-255 (decimal). To convert each of the three
				 * bytes to the range 0-1 divide it by 255.
				 * -------------------------------------------------------------
				 */
				int color = Integer.valueOf(colors[i].hex_value, 16).intValue();

				red = ((color & 0xFF0000) >> 16) / 255.0;
				green = ((color & 0x00FF00) >> 8) / 255.0;
				blue = (color & 0x0000FF) / 255.0;

				/*
				 * -------------------------------------------------------------
				 * Add a rectangle filled with the HTML color in the third
				 * column
				 * -------------------------------------------------------------
				 * 
				 * Since the cell doesn't cover a complete row but only one
				 * column it cannot be filled with color using one of the
				 * row-based shading options. We apply the Matchbox feature
				 * instead to fill the rectangle covered by the cell with the
				 * RGB color value calculated above.
				 */
				cellopts = "colwidth=" + c3 + " matchbox={fillcolor="
						+ colors[i].html_name + "}";

				tbl = p.add_table_cell(tbl, 3, row, "", cellopts);
				if (tbl == -1)
					throw new Exception("Error: " + p.get_errmsg());

				/*
				 * -------------------------------------------------------------
				 * Add the PDFlib color value in the fourth column of
				 * the current row. Allow a maximum (and a minimum) of four
				 * digits in the fraction portion of the number and output the
				 * PDFlib color values accordingly.
				 * -------------------------------------------------------------
				 */
				cellopts = optlist + " colwidth=" + c4 + " marginleft=20";

				form.setMaximumFractionDigits(4);
				form.setMinimumFractionDigits(4);

				tbl = p.add_table_cell(tbl, 4, row, form.format(red) + " "
						+ form.format(green) + " " + form.format(blue),
						cellopts);

				if (tbl == -1)
					throw new Exception("Error: " + p.get_errmsg());
			} /* for */

			/*
			 * -----------------------------------------------------------------
			 * Fit the table. Using "header=1" the table header will include the
			 * first line. Using "line=horother linewidth=0.3" the ruling is
			 * specified with a line width of 0.3 for all horizontal lines.
			 * -----------------------------------------------------------------
			 */
			optlist = "header=1 stroke={ {line=horother linewidth=0.3}}";

			do {
				p.begin_page_ext(0, 0, "width=a4.width height=a4.height");

				/* Place the table instance */
				result = p.fit_table(tbl, llx, lly, llx + c1 + c2 + c3 + c4,
						lly + nrows * rowheight, optlist);

				if (result.equals("_error"))
					throw new Exception("Couldn't place table : "
							+ p.get_errmsg());

				p.end_page_ext("");
			}
			while (result.equals("_boxfull"));

			/* Check the result; "_stop" means all is ok. */
			if (!result.equals("_stop")) {
				if (result.equals("_error")) {
					throw new Exception("Error when placing table: "
							+ p.get_errmsg());
				}
			}

			/* This will also delete Textflow handles used in the table */
			p.delete_table(tbl, "");

			p.end_document("");
		}
		catch (PDFlibException e) {
			System.err.print("PDFlib exception occurred:\n");
			System.err.print("[" + e.get_errnum() + "] " + e.get_apiname()
					+ ": " + e.get_errmsg() + "\n");
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
		finally {
			if (p != null) {
				p.delete();
			}
		}
	}
}
